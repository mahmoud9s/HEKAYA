﻿Imports System.Data.OleDb

Module DatabaseModule

    Public connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\KING\source\repos\HEKAYA\HekayaDB.accdb" ' <<< عدل هذا المسار!
    Public connection As OleDbConnection

    Public Sub OpenConnection()
        Try
            connection = New OleDbConnection(connectionString)
            connection.Open()
        Catch ex As Exception
            MessageBox.Show("خطأ في الاتصال بقاعدة البيانات: " & ex.Message)
        End Try
    End Sub

    Public Sub CloseConnection()
        Try
            If connection IsNot Nothing AndAlso connection.State = ConnectionState.Open Then
                connection.Close()
            End If
        Catch ex As Exception
            MessageBox.Show("خطأ في إغلاق الاتصال بقاعدة البيانات: " & ex.Message)
        End Try
    End Sub
End Module

