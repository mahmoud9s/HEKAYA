﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Hotels_Hurghada_Moderate_Budget
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Hotels_Hurghada_Moderate_Budget))
        Label5 = New Label()
        Label14 = New Label()
        PictureBox12 = New PictureBox()
        Label7 = New Label()
        Label9 = New Label()
        Label12 = New Label()
        Label13 = New Label()
        PictureBox9 = New PictureBox()
        PictureBox11 = New PictureBox()
        Label11 = New Label()
        Label10 = New Label()
        Label8 = New Label()
        Label6 = New Label()
        PictureBox10 = New PictureBox()
        PictureBox3 = New PictureBox()
        PictureBox8 = New PictureBox()
        PictureBox6 = New PictureBox()
        PictureBox7 = New PictureBox()
        PictureBox5 = New PictureBox()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        PictureBox2 = New PictureBox()
        PictureBox1 = New PictureBox()
        PictureBox4 = New PictureBox()
        CType(PictureBox12, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label5
        ' 
        Label5.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        Label5.AutoSize = True
        Label5.BackColor = Color.FromArgb(CByte(239), CByte(235), CByte(229))
        Label5.Font = New Font("Mongolian Baiti", 60F)
        Label5.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label5.Location = New Point(927, 77)
        Label5.Name = "Label5"
        Label5.Size = New Size(246, 85)
        Label5.TabIndex = 133
        Label5.Text = "Hotels"
        ' 
        ' Label14
        ' 
        Label14.Anchor = AnchorStyles.Left
        Label14.AutoSize = True
        Label14.BackColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label14.Font = New Font("Microsoft Sans Serif", 18F, FontStyle.Bold)
        Label14.ForeColor = Color.White
        Label14.Location = New Point(410, 210)
        Label14.Name = "Label14"
        Label14.Size = New Size(96, 29)
        Label14.TabIndex = 122
        Label14.Text = "Budget"
        ' 
        ' PictureBox12
        ' 
        PictureBox12.Anchor = AnchorStyles.Left
        PictureBox12.BackgroundImage = My.Resources.Resources.Picture18
        PictureBox12.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox12.Cursor = Cursors.Hand
        PictureBox12.Location = New Point(340, 164)
        PictureBox12.Margin = New Padding(3, 2, 3, 2)
        PictureBox12.Name = "PictureBox12"
        PictureBox12.Size = New Size(240, 103)
        PictureBox12.TabIndex = 119
        PictureBox12.TabStop = False
        ' 
        ' Label7
        ' 
        Label7.Anchor = AnchorStyles.Right
        Label7.Cursor = Cursors.Hand
        Label7.Font = New Font("Microsoft Sans Serif", 18F)
        Label7.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label7.Location = New Point(1447, 699)
        Label7.Name = "Label7"
        Label7.Size = New Size(402, 177)
        Label7.TabIndex = 132
        Label7.Text = "Elaria Hotel Hurghada features a spa, private beach, restaurant, and air-conditioned rooms with city or sea views. It’s 3.1 km from New Marina."
        ' 
        ' Label9
        ' 
        Label9.Anchor = AnchorStyles.Left
        Label9.Cursor = Cursors.Hand
        Label9.Font = New Font("Microsoft Sans Serif", 18F)
        Label9.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label9.Location = New Point(474, 699)
        Label9.Name = "Label9"
        Label9.Size = New Size(444, 232)
        Label9.TabIndex = 131
        Label9.Text = resources.GetString("Label9.Text")
        ' 
        ' Label12
        ' 
        Label12.Anchor = AnchorStyles.Right
        Label12.AutoSize = True
        Label12.Cursor = Cursors.Hand
        Label12.Font = New Font("Microsoft Sans Serif", 25F, FontStyle.Bold)
        Label12.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label12.Location = New Point(1447, 642)
        Label12.Name = "Label12"
        Label12.Size = New Size(374, 39)
        Label12.TabIndex = 130
        Label12.Text = "Elaria Hotel Hurghada"
        ' 
        ' Label13
        ' 
        Label13.Anchor = AnchorStyles.Left
        Label13.AutoSize = True
        Label13.Cursor = Cursors.Hand
        Label13.Font = New Font("Microsoft Sans Serif", 25F, FontStyle.Bold)
        Label13.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label13.Location = New Point(474, 642)
        Label13.Name = "Label13"
        Label13.Size = New Size(564, 39)
        Label13.TabIndex = 129
        Label13.Text = "Sunny Days Mirette Family Resort"
        ' 
        ' PictureBox9
        ' 
        PictureBox9.Anchor = AnchorStyles.Right
        PictureBox9.BackgroundImage = CType(resources.GetObject("PictureBox9.BackgroundImage"), Image)
        PictureBox9.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox9.BorderStyle = BorderStyle.FixedSingle
        PictureBox9.Cursor = Cursors.Hand
        PictureBox9.Location = New Point(1041, 634)
        PictureBox9.Margin = New Padding(3, 2, 3, 2)
        PictureBox9.Name = "PictureBox9"
        PictureBox9.Size = New Size(400, 273)
        PictureBox9.TabIndex = 128
        PictureBox9.TabStop = False
        ' 
        ' PictureBox11
        ' 
        PictureBox11.Anchor = AnchorStyles.Left
        PictureBox11.BackgroundImage = CType(resources.GetObject("PictureBox11.BackgroundImage"), Image)
        PictureBox11.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox11.BorderStyle = BorderStyle.FixedSingle
        PictureBox11.Cursor = Cursors.Hand
        PictureBox11.Location = New Point(93, 634)
        PictureBox11.Margin = New Padding(3, 2, 3, 2)
        PictureBox11.Name = "PictureBox11"
        PictureBox11.Size = New Size(359, 273)
        PictureBox11.TabIndex = 127
        PictureBox11.TabStop = False
        ' 
        ' Label11
        ' 
        Label11.Anchor = AnchorStyles.Right
        Label11.Cursor = Cursors.Hand
        Label11.Font = New Font("Microsoft Sans Serif", 18F)
        Label11.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label11.Location = New Point(1454, 400)
        Label11.Name = "Label11"
        Label11.Size = New Size(402, 193)
        Label11.TabIndex = 126
        Label11.Text = "Old Palace Resort in Sahl Hasheesh offers a private beach, spacious rooms, 3 restaurants, 4 bars, a heated pool, and a hot tub."
        ' 
        ' Label10
        ' 
        Label10.Anchor = AnchorStyles.Left
        Label10.Cursor = Cursors.Hand
        Label10.Font = New Font("Microsoft Sans Serif", 18F)
        Label10.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label10.Location = New Point(474, 400)
        Label10.Name = "Label10"
        Label10.Size = New Size(385, 193)
        Label10.TabIndex = 125
        Label10.Text = resources.GetString("Label10.Text")
        ' 
        ' Label8
        ' 
        Label8.Anchor = AnchorStyles.Right
        Label8.AutoSize = True
        Label8.Cursor = Cursors.Hand
        Label8.Font = New Font("Microsoft Sans Serif", 25F, FontStyle.Bold)
        Label8.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label8.Location = New Point(1447, 349)
        Label8.Name = "Label8"
        Label8.Size = New Size(310, 39)
        Label8.TabIndex = 124
        Label8.Text = "Old Palace Resort"
        ' 
        ' Label6
        ' 
        Label6.Anchor = AnchorStyles.Left
        Label6.AutoSize = True
        Label6.Cursor = Cursors.Hand
        Label6.Font = New Font("Microsoft Sans Serif", 25F, FontStyle.Bold)
        Label6.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label6.Location = New Point(474, 337)
        Label6.Name = "Label6"
        Label6.Size = New Size(454, 39)
        Label6.TabIndex = 123
        Label6.Text = "Kempinski Hotel Soma Bay"
        ' 
        ' PictureBox10
        ' 
        PictureBox10.Anchor = AnchorStyles.Right
        PictureBox10.BackgroundImage = CType(resources.GetObject("PictureBox10.BackgroundImage"), Image)
        PictureBox10.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox10.BorderStyle = BorderStyle.FixedSingle
        PictureBox10.Cursor = Cursors.Hand
        PictureBox10.Location = New Point(1041, 320)
        PictureBox10.Margin = New Padding(3, 2, 3, 2)
        PictureBox10.Name = "PictureBox10"
        PictureBox10.Size = New Size(400, 273)
        PictureBox10.TabIndex = 121
        PictureBox10.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Anchor = AnchorStyles.Left
        PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), Image)
        PictureBox3.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox3.BorderStyle = BorderStyle.FixedSingle
        PictureBox3.Cursor = Cursors.Hand
        PictureBox3.Location = New Point(93, 321)
        PictureBox3.Margin = New Padding(3, 2, 3, 2)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(359, 273)
        PictureBox3.TabIndex = 120
        PictureBox3.TabStop = False
        ' 
        ' PictureBox8
        ' 
        PictureBox8.BackColor = Color.Transparent
        PictureBox8.BackgroundImage = My.Resources.Resources.Picture7
        PictureBox8.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox8.Cursor = Cursors.Hand
        PictureBox8.Location = New Point(12, 11)
        PictureBox8.Margin = New Padding(3, 2, 3, 2)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(70, 39)
        PictureBox8.TabIndex = 118
        PictureBox8.TabStop = False
        ' 
        ' PictureBox6
        ' 
        PictureBox6.BackColor = Color.Transparent
        PictureBox6.BackgroundImage = My.Resources.Resources.Picture6
        PictureBox6.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox6.Cursor = Cursors.Hand
        PictureBox6.Location = New Point(93, 11)
        PictureBox6.Margin = New Padding(3, 2, 3, 2)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(55, 39)
        PictureBox6.TabIndex = 117
        PictureBox6.TabStop = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox7.BackColor = Color.Transparent
        PictureBox7.BackgroundImage = My.Resources.Resources.love
        PictureBox7.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox7.Cursor = Cursors.Hand
        PictureBox7.Location = New Point(1832, 11)
        PictureBox7.Margin = New Padding(3, 2, 3, 2)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(60, 39)
        PictureBox7.TabIndex = 116
        PictureBox7.TabStop = False
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox5.BackColor = Color.Transparent
        PictureBox5.BackgroundImage = My.Resources.Resources.Picture9
        PictureBox5.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox5.Cursor = Cursors.Hand
        PictureBox5.Location = New Point(1766, 11)
        PictureBox5.Margin = New Padding(3, 2, 3, 2)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(55, 39)
        PictureBox5.TabIndex = 115
        PictureBox5.TabStop = False
        ' 
        ' Label4
        ' 
        Label4.Anchor = AnchorStyles.Right
        Label4.AutoSize = True
        Label4.BackColor = Color.White
        Label4.Cursor = Cursors.Hand
        Label4.Font = New Font("Microsoft Sans Serif", 18F)
        Label4.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label4.Location = New Point(1274, 210)
        Label4.Name = "Label4"
        Label4.Size = New Size(144, 29)
        Label4.TabIndex = 114
        Label4.Text = "High budget"
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.None
        Label3.AutoSize = True
        Label3.BackColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label3.Cursor = Cursors.Hand
        Label3.Font = New Font("Microsoft Sans Serif", 16F, FontStyle.Bold)
        Label3.ForeColor = Color.White
        Label3.Location = New Point(949, 210)
        Label3.Name = "Label3"
        Label3.Size = New Size(190, 26)
        Label3.TabIndex = 113
        Label3.Text = "Moderate budget"
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Left
        Label2.AutoSize = True
        Label2.BackColor = Color.White
        Label2.Cursor = Cursors.Hand
        Label2.Font = New Font("Microsoft Sans Serif", 18F)
        Label2.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label2.Location = New Point(686, 210)
        Label2.Name = "Label2"
        Label2.Size = New Size(139, 29)
        Label2.TabIndex = 112
        Label2.Text = "Low budget"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Anchor = AnchorStyles.None
        PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), Image)
        PictureBox2.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox2.Cursor = Cursors.Hand
        PictureBox2.Location = New Point(927, 163)
        PictureBox2.Margin = New Padding(3, 2, 3, 2)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(240, 103)
        PictureBox2.TabIndex = 111
        PictureBox2.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Anchor = AnchorStyles.Right
        PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), Image)
        PictureBox1.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox1.Cursor = Cursors.Hand
        PictureBox1.Location = New Point(1218, 164)
        PictureBox1.Margin = New Padding(3, 2, 3, 2)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(240, 103)
        PictureBox1.TabIndex = 110
        PictureBox1.TabStop = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Anchor = AnchorStyles.Left
        PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), Image)
        PictureBox4.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox4.Cursor = Cursors.Hand
        PictureBox4.Location = New Point(637, 164)
        PictureBox4.Margin = New Padding(3, 2, 3, 2)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(240, 103)
        PictureBox4.TabIndex = 109
        PictureBox4.TabStop = False
        ' 
        ' Hotels_Hurghada_Moderate_Budget
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(239), CByte(235), CByte(229))
        ClientSize = New Size(1904, 1041)
        Controls.Add(Label5)
        Controls.Add(Label14)
        Controls.Add(PictureBox12)
        Controls.Add(Label7)
        Controls.Add(Label9)
        Controls.Add(Label12)
        Controls.Add(Label13)
        Controls.Add(PictureBox9)
        Controls.Add(PictureBox11)
        Controls.Add(Label11)
        Controls.Add(Label10)
        Controls.Add(Label8)
        Controls.Add(Label6)
        Controls.Add(PictureBox10)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox8)
        Controls.Add(PictureBox6)
        Controls.Add(PictureBox7)
        Controls.Add(PictureBox5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        Controls.Add(PictureBox4)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Margin = New Padding(3, 2, 3, 2)
        Name = "Hotels_Hurghada_Moderate_Budget"
        Text = "Hotels_Hurghada_Moderate_Budget"
        WindowState = FormWindowState.Maximized
        CType(PictureBox12, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label5 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents PictureBox12 As PictureBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
End Class
