﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class High_Budget_Siwa_Hotels_La_Siwa_Resort
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(High_Budget_Siwa_Hotels_La_Siwa_Resort))
        Label11 = New Label()
        Label10 = New Label()
        Label9 = New Label()
        Label8 = New Label()
        Label7 = New Label()
        Label6 = New Label()
        LinkLabel1 = New LinkLabel()
        PictureBox6 = New PictureBox()
        Label5 = New Label()
        PictureBox5 = New PictureBox()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        PictureBox4 = New PictureBox()
        PictureBox3 = New PictureBox()
        PictureBox2 = New PictureBox()
        PictureBox1 = New PictureBox()
        Label1 = New Label()
        PictureBox8 = New PictureBox()
        PictureBox7 = New PictureBox()
        PictureBox9 = New PictureBox()
        PictureBox10 = New PictureBox()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label11
        ' 
        Label11.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label11.AutoSize = True
        Label11.Font = New Font("Microsoft Sans Serif", 20F)
        Label11.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label11.Location = New Point(65, 767)
        Label11.Name = "Label11"
        Label11.Size = New Size(354, 31)
        Label11.TabIndex = 124
        Label11.Text = "1200 to 1500 EGP  per night"
        ' 
        ' Label10
        ' 
        Label10.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label10.AutoSize = True
        Label10.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label10.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label10.Location = New Point(65, 719)
        Label10.Name = "Label10"
        Label10.Size = New Size(202, 37)
        Label10.TabIndex = 123
        Label10.Text = "Price Range"
        ' 
        ' Label9
        ' 
        Label9.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label9.AutoSize = True
        Label9.Font = New Font("Microsoft Sans Serif", 20F)
        Label9.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label9.Location = New Point(438, 477)
        Label9.Name = "Label9"
        Label9.Size = New Size(475, 186)
        Label9.TabIndex = 122
        Label9.Text = "Swimming Pool:" & vbCrLf & "Eco-Friendly Features: Built" & vbCrLf & " with traditional Siwan" & vbCrLf & " materials such as salt blocks and clay" & vbCrLf & ",emphasizing sustainability. Bar" & vbCrLf & "Excellent Breakfast"
        ' 
        ' Label8
        ' 
        Label8.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label8.AutoSize = True
        Label8.Font = New Font("Microsoft Sans Serif", 20F)
        Label8.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label8.Location = New Point(65, 477)
        Label8.Name = "Label8"
        Label8.Size = New Size(278, 155)
        Label8.TabIndex = 121
        Label8.Text = "Accommodation " & vbCrLf & "OptionsFree Wifi" & vbCrLf & "Family rooms" & vbCrLf & "Parking: Free on-site " & vbCrLf & "parking for guestsSpa"
        ' 
        ' Label7
        ' 
        Label7.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label7.AutoSize = True
        Label7.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label7.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label7.Location = New Point(57, 427)
        Label7.Name = "Label7"
        Label7.Size = New Size(348, 37)
        Label7.TabIndex = 120
        Label7.Text = "Most popular facilities"
        ' 
        ' Label6
        ' 
        Label6.Font = New Font("Lucida Sans Unicode", 20.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label6.Location = New Point(57, 262)
        Label6.Name = "Label6"
        Label6.Size = New Size(820, 149)
        Label6.TabIndex = 119
        Label6.Text = resources.GetString("Label6.Text")
        ' 
        ' LinkLabel1
        ' 
        LinkLabel1.AutoSize = True
        LinkLabel1.Font = New Font("Segoe UI", 12F)
        LinkLabel1.Location = New Point(74, 239)
        LinkLabel1.Name = "LinkLabel1"
        LinkLabel1.Size = New Size(820, 21)
        LinkLabel1.TabIndex = 118
        LinkLabel1.TabStop = True
        LinkLabel1.Text = "Situated in Siwa Oasis, approximately 306 kilometers south of Marsa Matrouh, and about 810 kilometers from Cairo ." & vbLf
        ' 
        ' PictureBox6
        ' 
        PictureBox6.BackColor = Color.Transparent
        PictureBox6.BackgroundImage = CType(resources.GetObject("PictureBox6.BackgroundImage"), Image)
        PictureBox6.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox6.Cursor = Cursors.Hand
        PictureBox6.Location = New Point(24, 223)
        PictureBox6.Margin = New Padding(3, 2, 3, 2)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(44, 37)
        PictureBox6.TabIndex = 117
        PictureBox6.TabStop = False
        ' 
        ' Label5
        ' 
        Label5.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label5.AutoSize = True
        Label5.Font = New Font("Mongolian Baiti", 60F)
        Label5.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label5.Location = New Point(24, 127)
        Label5.Name = "Label5"
        Label5.Size = New Size(532, 85)
        Label5.TabIndex = 116
        Label5.Text = "La Siwa Resort"
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), Image)
        PictureBox5.Location = New Point(985, 136)
        PictureBox5.Margin = New Padding(3, 2, 3, 2)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(900, 792)
        PictureBox5.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox5.TabIndex = 115
        PictureBox5.TabStop = False
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Cursor = Cursors.Hand
        Label4.Font = New Font("Microsoft Sans Serif", 12F)
        Label4.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label4.Location = New Point(91, 88)
        Label4.Name = "Label4"
        Label4.Size = New Size(68, 20)
        Label4.TabIndex = 114
        Label4.Text = "Hotels >"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Cursor = Cursors.Hand
        Label3.Font = New Font("Microsoft Sans Serif", 12F)
        Label3.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label3.Location = New Point(165, 88)
        Label3.Name = "Label3"
        Label3.Size = New Size(117, 20)
        Label3.TabIndex = 113
        Label3.Text = "La Siwa Resort"
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Label2.AutoSize = True
        Label2.BackColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label2.Cursor = Cursors.Hand
        Label2.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Bold)
        Label2.ForeColor = Color.White
        Label2.Location = New Point(1773, 105)
        Label2.Name = "Label2"
        Label2.Size = New Size(87, 20)
        Label2.TabIndex = 112
        Label2.Text = "Book now"
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), Image)
        PictureBox4.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox4.Cursor = Cursors.Hand
        PictureBox4.Location = New Point(1744, 92)
        PictureBox4.Margin = New Padding(3, 2, 3, 2)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(141, 42)
        PictureBox4.TabIndex = 111
        PictureBox4.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), Image)
        PictureBox3.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox3.Cursor = Cursors.Hand
        PictureBox3.Location = New Point(1639, 97)
        PictureBox3.Margin = New Padding(3, 2, 3, 2)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(41, 38)
        PictureBox3.TabIndex = 110
        PictureBox3.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), Image)
        PictureBox2.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox2.Cursor = Cursors.Hand
        PictureBox2.Location = New Point(1686, 97)
        PictureBox2.Margin = New Padding(3, 2, 3, 2)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(44, 38)
        PictureBox2.TabIndex = 109
        PictureBox2.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), Image)
        PictureBox1.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox1.Cursor = Cursors.Hand
        PictureBox1.Location = New Point(985, 95)
        PictureBox1.Margin = New Padding(3, 2, 3, 2)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(157, 39)
        PictureBox1.TabIndex = 108
        PictureBox1.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Cursor = Cursors.Hand
        Label1.Font = New Font("Microsoft Sans Serif", 12F)
        Label1.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label1.Location = New Point(24, 88)
        Label1.Name = "Label1"
        Label1.Size = New Size(56, 20)
        Label1.TabIndex = 107
        Label1.Text = "Siwa >"
        ' 
        ' PictureBox8
        ' 
        PictureBox8.BackColor = Color.Transparent
        PictureBox8.BackgroundImage = My.Resources.Resources.Picture7
        PictureBox8.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox8.Cursor = Cursors.Hand
        PictureBox8.Location = New Point(12, 11)
        PictureBox8.Margin = New Padding(3, 2, 3, 2)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(70, 39)
        PictureBox8.TabIndex = 106
        PictureBox8.TabStop = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.BackColor = Color.Transparent
        PictureBox7.BackgroundImage = My.Resources.Resources.Picture6
        PictureBox7.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox7.Cursor = Cursors.Hand
        PictureBox7.Location = New Point(99, 11)
        PictureBox7.Margin = New Padding(3, 2, 3, 2)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(55, 39)
        PictureBox7.TabIndex = 105
        PictureBox7.TabStop = False
        ' 
        ' PictureBox9
        ' 
        PictureBox9.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox9.BackColor = Color.Transparent
        PictureBox9.BackgroundImage = My.Resources.Resources.love
        PictureBox9.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox9.Cursor = Cursors.Hand
        PictureBox9.Location = New Point(1752, 11)
        PictureBox9.Margin = New Padding(3, 2, 3, 2)
        PictureBox9.Name = "PictureBox9"
        PictureBox9.Size = New Size(60, 39)
        PictureBox9.TabIndex = 104
        PictureBox9.TabStop = False
        ' 
        ' PictureBox10
        ' 
        PictureBox10.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox10.BackColor = Color.Transparent
        PictureBox10.BackgroundImage = My.Resources.Resources.Picture9
        PictureBox10.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox10.Cursor = Cursors.Hand
        PictureBox10.Location = New Point(1827, 11)
        PictureBox10.Margin = New Padding(3, 2, 3, 2)
        PictureBox10.Name = "PictureBox10"
        PictureBox10.Size = New Size(55, 39)
        PictureBox10.TabIndex = 103
        PictureBox10.TabStop = False
        ' 
        ' High_Budget_Siwa_Hotels_La_Siwa_Resort
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(239), CByte(235), CByte(229))
        ClientSize = New Size(1904, 1041)
        Controls.Add(Label11)
        Controls.Add(Label10)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(LinkLabel1)
        Controls.Add(PictureBox6)
        Controls.Add(Label5)
        Controls.Add(PictureBox5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(PictureBox4)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        Controls.Add(Label1)
        Controls.Add(PictureBox8)
        Controls.Add(PictureBox7)
        Controls.Add(PictureBox9)
        Controls.Add(PictureBox10)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Name = "High_Budget_Siwa_Hotels_La_Siwa_Resort"
        Text = "High_Budget_Siwa_Hotels_La_Siwa_Resort"
        WindowState = FormWindowState.Maximized
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
End Class
