﻿Imports System.Data.OleDb

Public Class Login_page

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Sign_Up.Show()
        Me.Hide()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Try
            DatabaseModule.OpenConnection()

            Dim command As New OleDbCommand()
            command.Connection = DatabaseModule.connection
            command.CommandText = "SELECT * FROM Users WHERE Username = @Username AND Password = @Password"

            command.Parameters.AddWithValue("@Username", txtEmailAddress.Text)
            command.Parameters.AddWithValue("@Password", txtPassword.Text)

            Dim reader As OleDbDataReader = command.ExecuteReader()

            If reader.HasRows Then
                lblMessage.Text = "تم تسجيل الدخول بنجاح."
                lblMessage.ForeColor = Color.Green
                Me.Hide()
                Choosse_Your_Distination.Show()
            Else
                lblMessage.Text = "اسم المستخدم أو كلمة المرور غير صحيحة."
                lblMessage.ForeColor = Color.Red
            End If
            reader.Close()
        Catch ex As Exception
            lblMessage.Text = "حدث خطأ أثناء تسجيل الدخول: " & ex.Message
            lblMessage.ForeColor = Color.Red
        Finally
            DatabaseModule.CloseConnection()
        End Try
        Choosse_Your_Distination.Show()
        Me.Hide()
    End Sub

    Private Sub Login_page_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub txtUsername_TextChanged(sender As Object, e As EventArgs) Handles txtEmailAddress.TextChanged

    End Sub
End Class