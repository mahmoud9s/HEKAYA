﻿Imports System.Data.OleDb
Imports HEKAYA.DatabaseModule
Public Class Sign_Up
    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Login_page.Show()
        Me.Hide()
    End Sub

    Private Sub btnSignUp_Click(sender As Object, e As EventArgs) Handles btnSignUp.Click
        Try
            ' 1. التحقق من تطابق كلمتي المرور
            If txtPassword.Text <> txtConfirmPassword.Text Then
                lblMessage.Text = "كلمتا المرور غير متطابقتين."
                lblMessage.ForeColor = Color.Red
                Exit Sub
            End If

            ' 2. فتح الاتصال بقاعدة البيانات
            DatabaseModule.OpenConnection()

            ' 3. إنشاء استعلام SQL لإضافة المستخدم
            Dim command As New OleDbCommand()
            command.Connection = DatabaseModule.connection
            command.CommandText = "INSERT INTO Users ([FullName], [PhoneNumber], [EmailAddress], [Password], [Username]) VALUES (@FullName, @PhoneNumber, @EmailAddress, @Password, @Username)"
            ' 4. إضافة قيم الحقول كمعاملات للاستعلام (SQL Parameters)
            command.Parameters.AddWithValue("@PhoneNumber", If(String.IsNullOrEmpty(txtPhoneNumber.Text), "", txtPhoneNumber.Text))
            command.Parameters.AddWithValue("@Password", If(String.IsNullOrEmpty(txtPassword.Text), "", txtPassword.Text))
            command.Parameters.AddWithValue("@Username", If(String.IsNullOrEmpty(txtEmailAddress.Text), "", txtEmailAddress.Text))
            ' 5. تنفيذ استعلام SQL
            command.ExecuteNonQuery()

            ' 6. عرض رسالة نجاح للمستخدم
            lblMessage.Text = "تم تسجيل المستخدم بنجاح."
            lblMessage.ForeColor = Color.Green

            ' 7. مسح حقول الإدخال   
            txtPhoneNumber.Clear()
            txtEmailAddress.Clear()
            txtPassword.Clear()
            txtConfirmPassword.Clear()
        Catch ex As Exception
            lblMessage.Text = "حدث خطأ أثناء التسجيل: " & ex.Message
            MessageBox.Show(ex.Message)
            lblMessage.ForeColor = Color.Red
        Finally
            ' 8. إغلاق الاتصال بقاعدة البيانات
            DatabaseModule.CloseConnection()
        End Try
    End Sub

    Private Sub Sign_Up_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class