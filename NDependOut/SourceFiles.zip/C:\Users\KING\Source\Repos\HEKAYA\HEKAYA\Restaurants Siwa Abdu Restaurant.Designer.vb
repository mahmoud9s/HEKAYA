﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Restaurants_Siwa_Abdu_Restaurant
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Restaurants_Siwa_Abdu_Restaurant))
        Label18 = New Label()
        Label1 = New Label()
        Label9 = New Label()
        Label11 = New Label()
        Label12 = New Label()
        Label14 = New Label()
        Label10 = New Label()
        Label8 = New Label()
        Label7 = New Label()
        Label6 = New Label()
        LinkLabel1 = New LinkLabel()
        PictureBox6 = New PictureBox()
        Label5 = New Label()
        PictureBox8 = New PictureBox()
        PictureBox7 = New PictureBox()
        PictureBox9 = New PictureBox()
        PictureBox10 = New PictureBox()
        PictureBox5 = New PictureBox()
        Label2 = New Label()
        PictureBox4 = New PictureBox()
        PictureBox3 = New PictureBox()
        PictureBox2 = New PictureBox()
        PictureBox1 = New PictureBox()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label18
        ' 
        Label18.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label18.Font = New Font("Microsoft Sans Serif", 20F)
        Label18.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label18.Location = New Point(16, 597)
        Label18.Name = "Label18"
        Label18.Size = New Size(944, 472)
        Label18.TabIndex = 447
        Label18.Text = resources.GetString("Label18.Text")
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label1.AutoSize = True
        Label1.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label1.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label1.Location = New Point(16, 549)
        Label1.Name = "Label1"
        Label1.Size = New Size(286, 37)
        Label1.TabIndex = 446
        Label1.Text = "Signature Dishes:"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Cursor = Cursors.Hand
        Label9.Font = New Font("Microsoft Sans Serif", 12F)
        Label9.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label9.Location = New Point(65, 77)
        Label9.Name = "Label9"
        Label9.Size = New Size(110, 20)
        Label9.TabIndex = 445
        Label9.Text = "Restaurants >"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Cursor = Cursors.Hand
        Label11.Font = New Font("Microsoft Sans Serif", 12F)
        Label11.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label11.Location = New Point(177, 77)
        Label11.Name = "Label11"
        Label11.Size = New Size(131, 20)
        Label11.TabIndex = 444
        Label11.Text = "Abdu Restaurant"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Cursor = Cursors.Hand
        Label12.Font = New Font("Microsoft Sans Serif", 12F)
        Label12.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label12.Location = New Point(16, 77)
        Label12.Name = "Label12"
        Label12.Size = New Size(60, 20)
        Label12.TabIndex = 443
        Label12.Text = "Siwa > "
        ' 
        ' Label14
        ' 
        Label14.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label14.AutoSize = True
        Label14.Font = New Font("Microsoft Sans Serif", 20F, FontStyle.Bold)
        Label14.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label14.Location = New Point(44, 716)
        Label14.Name = "Label14"
        Label14.Size = New Size(0, 31)
        Label14.TabIndex = 438
        ' 
        ' Label10
        ' 
        Label10.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label10.AutoSize = True
        Label10.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label10.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label10.Location = New Point(478, 667)
        Label10.Name = "Label10"
        Label10.Size = New Size(0, 37)
        Label10.TabIndex = 437
        ' 
        ' Label8
        ' 
        Label8.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label8.AutoSize = True
        Label8.Font = New Font("Microsoft Sans Serif", 20F)
        Label8.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label8.Location = New Point(16, 510)
        Label8.Name = "Label8"
        Label8.Size = New Size(168, 31)
        Label8.TabIndex = 436
        Label8.Text = "EGP 5 to 25."
        ' 
        ' Label7
        ' 
        Label7.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label7.AutoSize = True
        Label7.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label7.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label7.Location = New Point(16, 467)
        Label7.Name = "Label7"
        Label7.Size = New Size(212, 37)
        Label7.TabIndex = 435
        Label7.Text = "Price Range:"
        ' 
        ' Label6
        ' 
        Label6.Font = New Font("Lucida Sans Unicode", 22.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label6.Location = New Point(12, 220)
        Label6.Name = "Label6"
        Label6.Size = New Size(967, 235)
        Label6.TabIndex = 434
        Label6.Text = resources.GetString("Label6.Text")
        ' 
        ' LinkLabel1
        ' 
        LinkLabel1.AutoSize = True
        LinkLabel1.Font = New Font("Segoe UI", 20F)
        LinkLabel1.LinkColor = SystemColors.HotTrack
        LinkLabel1.Location = New Point(65, 182)
        LinkLabel1.Name = "LinkLabel1"
        LinkLabel1.Size = New Size(452, 37)
        LinkLabel1.TabIndex = 433
        LinkLabel1.TabStop = True
        LinkLabel1.Text = "In the Very Centre, Siwa 51714 Egypt"
        ' 
        ' PictureBox6
        ' 
        PictureBox6.BackColor = Color.Transparent
        PictureBox6.BackgroundImage = CType(resources.GetObject("PictureBox6.BackgroundImage"), Image)
        PictureBox6.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox6.Cursor = Cursors.Hand
        PictureBox6.Location = New Point(16, 181)
        PictureBox6.Margin = New Padding(3, 2, 3, 2)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(44, 36)
        PictureBox6.TabIndex = 432
        PictureBox6.TabStop = False
        ' 
        ' Label5
        ' 
        Label5.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label5.AutoSize = True
        Label5.Font = New Font("Mongolian Baiti", 46F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label5.Location = New Point(12, 118)
        Label5.Name = "Label5"
        Label5.Size = New Size(457, 66)
        Label5.TabIndex = 431
        Label5.Text = "Abdu Restaurant"
        ' 
        ' PictureBox8
        ' 
        PictureBox8.BackColor = Color.Transparent
        PictureBox8.BackgroundImage = My.Resources.Resources.Picture7
        PictureBox8.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox8.Cursor = Cursors.Hand
        PictureBox8.Location = New Point(12, 11)
        PictureBox8.Margin = New Padding(3, 2, 3, 2)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(70, 38)
        PictureBox8.TabIndex = 428
        PictureBox8.TabStop = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.BackColor = Color.Transparent
        PictureBox7.BackgroundImage = My.Resources.Resources.Picture6
        PictureBox7.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox7.Cursor = Cursors.Hand
        PictureBox7.Location = New Point(98, 11)
        PictureBox7.Margin = New Padding(3, 2, 3, 2)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(55, 38)
        PictureBox7.TabIndex = 427
        PictureBox7.TabStop = False
        ' 
        ' PictureBox9
        ' 
        PictureBox9.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox9.BackColor = Color.Transparent
        PictureBox9.BackgroundImage = My.Resources.Resources.love
        PictureBox9.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox9.Cursor = Cursors.Hand
        PictureBox9.Location = New Point(1771, 11)
        PictureBox9.Margin = New Padding(3, 2, 3, 2)
        PictureBox9.Name = "PictureBox9"
        PictureBox9.Size = New Size(60, 38)
        PictureBox9.TabIndex = 426
        PictureBox9.TabStop = False
        ' 
        ' PictureBox10
        ' 
        PictureBox10.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox10.BackColor = Color.Transparent
        PictureBox10.BackgroundImage = My.Resources.Resources.Picture9
        PictureBox10.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox10.Cursor = Cursors.Hand
        PictureBox10.Location = New Point(1837, 11)
        PictureBox10.Margin = New Padding(3, 2, 3, 2)
        PictureBox10.Name = "PictureBox10"
        PictureBox10.Size = New Size(55, 38)
        PictureBox10.TabIndex = 425
        PictureBox10.TabStop = False
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), Image)
        PictureBox5.Location = New Point(985, 136)
        PictureBox5.Margin = New Padding(3, 2, 3, 2)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(900, 792)
        PictureBox5.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox5.TabIndex = 430
        PictureBox5.TabStop = False
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Label2.AutoSize = True
        Label2.BackColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label2.Cursor = Cursors.Hand
        Label2.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Bold)
        Label2.ForeColor = Color.White
        Label2.Location = New Point(1771, 102)
        Label2.Name = "Label2"
        Label2.Size = New Size(87, 20)
        Label2.TabIndex = 452
        Label2.Text = "Book now"
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox4.BackColor = Color.FromArgb(CByte(239), CByte(235), CByte(229))
        PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), Image)
        PictureBox4.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox4.Cursor = Cursors.Hand
        PictureBox4.Location = New Point(1744, 90)
        PictureBox4.Margin = New Padding(3, 2, 3, 2)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(141, 42)
        PictureBox4.TabIndex = 451
        PictureBox4.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox3.BackColor = Color.FromArgb(CByte(239), CByte(235), CByte(229))
        PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), Image)
        PictureBox3.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox3.Cursor = Cursors.Hand
        PictureBox3.Location = New Point(1639, 95)
        PictureBox3.Margin = New Padding(3, 2, 3, 2)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(41, 38)
        PictureBox3.TabIndex = 450
        PictureBox3.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox2.BackColor = Color.FromArgb(CByte(239), CByte(235), CByte(229))
        PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), Image)
        PictureBox2.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox2.Cursor = Cursors.Hand
        PictureBox2.Location = New Point(1686, 95)
        PictureBox2.Margin = New Padding(3, 2, 3, 2)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(44, 38)
        PictureBox2.TabIndex = 449
        PictureBox2.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox1.BackColor = Color.FromArgb(CByte(239), CByte(235), CByte(229))
        PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), Image)
        PictureBox1.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox1.Cursor = Cursors.Hand
        PictureBox1.Location = New Point(985, 93)
        PictureBox1.Margin = New Padding(3, 2, 3, 2)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(157, 39)
        PictureBox1.TabIndex = 448
        PictureBox1.TabStop = False
        ' 
        ' Restaurants_Siwa_Abdu_Restaurant
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1904, 1041)
        Controls.Add(Label2)
        Controls.Add(PictureBox4)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        Controls.Add(Label18)
        Controls.Add(Label1)
        Controls.Add(Label9)
        Controls.Add(Label11)
        Controls.Add(Label12)
        Controls.Add(Label14)
        Controls.Add(Label10)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(LinkLabel1)
        Controls.Add(PictureBox6)
        Controls.Add(Label5)
        Controls.Add(PictureBox8)
        Controls.Add(PictureBox7)
        Controls.Add(PictureBox9)
        Controls.Add(PictureBox10)
        Controls.Add(PictureBox5)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Margin = New Padding(3, 2, 3, 2)
        Name = "Restaurants_Siwa_Abdu_Restaurant"
        Text = "Restaurants_Siwa_Abdu_Restaurant"
        WindowState = FormWindowState.Maximized
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label18 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
End Class
