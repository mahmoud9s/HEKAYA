﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class High_Budget_Cairo_Hotels_Waldorf_Astoria_Cairo_Heliopolis
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(High_Budget_Cairo_Hotels_Waldorf_Astoria_Cairo_Heliopolis))
        Label11 = New Label()
        Label10 = New Label()
        Label9 = New Label()
        Label8 = New Label()
        Label7 = New Label()
        Label6 = New Label()
        LinkLabel1 = New LinkLabel()
        PictureBox6 = New PictureBox()
        Label5 = New Label()
        PictureBox5 = New PictureBox()
        Label4 = New Label()
        Label3 = New Label()
        Label1 = New Label()
        Label2 = New Label()
        PictureBox4 = New PictureBox()
        PictureBox3 = New PictureBox()
        PictureBox2 = New PictureBox()
        PictureBox9 = New PictureBox()
        PictureBox10 = New PictureBox()
        Label12 = New Label()
        PictureBox1 = New PictureBox()
        PictureBox7 = New PictureBox()
        PictureBox8 = New PictureBox()
        PictureBox11 = New PictureBox()
        PictureBox12 = New PictureBox()
        PictureBox13 = New PictureBox()
        PictureBox14 = New PictureBox()
        PictureBox15 = New PictureBox()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox12, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox13, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox14, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox15, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label11
        ' 
        Label11.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label11.AutoSize = True
        Label11.Font = New Font("Microsoft Sans Serif", 20F)
        Label11.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label11.Location = New Point(38, 896)
        Label11.Name = "Label11"
        Label11.Size = New Size(283, 31)
        Label11.TabIndex = 80
        Label11.Text = "$250 to $400 per night"
        ' 
        ' Label10
        ' 
        Label10.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label10.AutoSize = True
        Label10.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label10.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label10.Location = New Point(38, 848)
        Label10.Name = "Label10"
        Label10.Size = New Size(202, 37)
        Label10.TabIndex = 79
        Label10.Text = "Price Range"
        ' 
        ' Label9
        ' 
        Label9.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label9.Font = New Font("Microsoft Sans Serif", 20F)
        Label9.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label9.Location = New Point(346, 606)
        Label9.Name = "Label9"
        Label9.Size = New Size(298, 411)
        Label9.TabIndex = 78
        Label9.Text = "Fitness center" & vbCrLf & "3 restaurants" & vbCrLf & "Non-smoking rooms" & vbCrLf & "Bar" & vbCrLf & "Excellent Breakfast" & vbCrLf
        ' 
        ' Label8
        ' 
        Label8.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label8.Font = New Font("Microsoft Sans Serif", 20F)
        Label8.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label8.Location = New Point(38, 606)
        Label8.Name = "Label8"
        Label8.Size = New Size(273, 411)
        Label8.TabIndex = 77
        Label8.Text = "Outdoor swimming pool" & vbCrLf & "Free Wifi" & vbCrLf & "Family rooms" & vbCrLf & "Private Parking" & vbCrLf & "Spa" & vbCrLf
        ' 
        ' Label7
        ' 
        Label7.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label7.AutoSize = True
        Label7.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label7.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label7.Location = New Point(29, 556)
        Label7.Name = "Label7"
        Label7.Size = New Size(348, 37)
        Label7.TabIndex = 76
        Label7.Text = "Most popular facilities"
        ' 
        ' Label6
        ' 
        Label6.Font = New Font("Microsoft Sans Serif", 22F)
        Label6.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label6.Location = New Point(24, 266)
        Label6.Name = "Label6"
        Label6.Size = New Size(681, 290)
        Label6.TabIndex = 75
        Label6.Text = resources.GetString("Label6.Text")
        ' 
        ' LinkLabel1
        ' 
        LinkLabel1.AutoSize = True
        LinkLabel1.Font = New Font("Segoe UI", 20F)
        LinkLabel1.Location = New Point(64, 227)
        LinkLabel1.Name = "LinkLabel1"
        LinkLabel1.Size = New Size(746, 37)
        LinkLabel1.TabIndex = 74
        LinkLabel1.TabStop = True
        LinkLabel1.Text = "Orouba Street Cairo Heliopolis, Egypt, Cairo, Egypt show map"
        ' 
        ' PictureBox6
        ' 
        PictureBox6.BackColor = Color.Transparent
        PictureBox6.BackgroundImage = CType(resources.GetObject("PictureBox6.BackgroundImage"), Image)
        PictureBox6.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox6.Cursor = Cursors.Hand
        PictureBox6.Location = New Point(24, 227)
        PictureBox6.Margin = New Padding(3, 2, 3, 2)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(44, 37)
        PictureBox6.TabIndex = 73
        PictureBox6.TabStop = False
        ' 
        ' Label5
        ' 
        Label5.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label5.AutoSize = True
        Label5.Font = New Font("Microsoft Sans Serif", 40F)
        Label5.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label5.Location = New Point(12, 140)
        Label5.Name = "Label5"
        Label5.Size = New Size(793, 63)
        Label5.TabIndex = 72
        Label5.Text = "Waldorf Astoria Cairo Heliopolis"
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), Image)
        PictureBox5.Location = New Point(976, 119)
        PictureBox5.Margin = New Padding(3, 2, 3, 2)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(900, 792)
        PictureBox5.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox5.TabIndex = 71
        PictureBox5.TabStop = False
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Cursor = Cursors.Hand
        Label4.Font = New Font("Microsoft Sans Serif", 12F)
        Label4.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label4.Location = New Point(70, 64)
        Label4.Name = "Label4"
        Label4.Size = New Size(68, 20)
        Label4.TabIndex = 70
        Label4.Text = "Hotels >"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Cursor = Cursors.Hand
        Label3.Font = New Font("Microsoft Sans Serif", 12F)
        Label3.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label3.Location = New Point(139, 64)
        Label3.Name = "Label3"
        Label3.Size = New Size(231, 20)
        Label3.TabIndex = 69
        Label3.Text = "Waldorf Astoria Cairo Heliopolis"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Cursor = Cursors.Hand
        Label1.Font = New Font("Microsoft Sans Serif", 12F)
        Label1.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label1.Location = New Point(12, 64)
        Label1.Name = "Label1"
        Label1.Size = New Size(63, 20)
        Label1.TabIndex = 63
        Label1.Text = "Cairo > "
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Label2.AutoSize = True
        Label2.BackColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label2.Cursor = Cursors.Hand
        Label2.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Bold)
        Label2.ForeColor = Color.White
        Label2.Location = New Point(2608, 238)
        Label2.Name = "Label2"
        Label2.Size = New Size(87, 20)
        Label2.TabIndex = 89
        Label2.Text = "Book now"
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), Image)
        PictureBox4.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox4.Cursor = Cursors.Hand
        PictureBox4.Location = New Point(2585, 225)
        PictureBox4.Margin = New Padding(3, 2, 3, 2)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(141, 42)
        PictureBox4.TabIndex = 88
        PictureBox4.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), Image)
        PictureBox3.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox3.Cursor = Cursors.Hand
        PictureBox3.Location = New Point(2528, 229)
        PictureBox3.Margin = New Padding(3, 2, 3, 2)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(51, 38)
        PictureBox3.TabIndex = 87
        PictureBox3.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), Image)
        PictureBox2.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox2.Cursor = Cursors.Hand
        PictureBox2.Location = New Point(2466, 229)
        PictureBox2.Margin = New Padding(3, 2, 3, 2)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(46, 38)
        PictureBox2.TabIndex = 86
        PictureBox2.TabStop = False
        ' 
        ' PictureBox9
        ' 
        PictureBox9.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox9.BackColor = Color.Transparent
        PictureBox9.BackgroundImage = My.Resources.Resources.love
        PictureBox9.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox9.Cursor = Cursors.Hand
        PictureBox9.Location = New Point(2608, 164)
        PictureBox9.Margin = New Padding(3, 2, 3, 2)
        PictureBox9.Name = "PictureBox9"
        PictureBox9.Size = New Size(60, 39)
        PictureBox9.TabIndex = 82
        PictureBox9.TabStop = False
        ' 
        ' PictureBox10
        ' 
        PictureBox10.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox10.BackColor = Color.Transparent
        PictureBox10.BackgroundImage = My.Resources.Resources.Picture9
        PictureBox10.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox10.Cursor = Cursors.Hand
        PictureBox10.Location = New Point(2683, 164)
        PictureBox10.Margin = New Padding(3, 2, 3, 2)
        PictureBox10.Name = "PictureBox10"
        PictureBox10.Size = New Size(55, 39)
        PictureBox10.TabIndex = 81
        PictureBox10.TabStop = False
        ' 
        ' Label12
        ' 
        Label12.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Label12.AutoSize = True
        Label12.BackColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label12.Cursor = Cursors.Hand
        Label12.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Bold)
        Label12.ForeColor = Color.White
        Label12.Location = New Point(1746, 85)
        Label12.Name = "Label12"
        Label12.Size = New Size(87, 20)
        Label12.TabIndex = 167
        Label12.Text = "Book now"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), Image)
        PictureBox1.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox1.Cursor = Cursors.Hand
        PictureBox1.Location = New Point(1724, 72)
        PictureBox1.Margin = New Padding(3, 2, 3, 2)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(141, 42)
        PictureBox1.TabIndex = 166
        PictureBox1.TabStop = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox7.BackgroundImage = CType(resources.GetObject("PictureBox7.BackgroundImage"), Image)
        PictureBox7.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox7.Cursor = Cursors.Hand
        PictureBox7.Location = New Point(1667, 76)
        PictureBox7.Margin = New Padding(3, 2, 3, 2)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(51, 38)
        PictureBox7.TabIndex = 165
        PictureBox7.TabStop = False
        ' 
        ' PictureBox8
        ' 
        PictureBox8.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox8.BackgroundImage = CType(resources.GetObject("PictureBox8.BackgroundImage"), Image)
        PictureBox8.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox8.Cursor = Cursors.Hand
        PictureBox8.Location = New Point(1605, 76)
        PictureBox8.Margin = New Padding(3, 2, 3, 2)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(46, 38)
        PictureBox8.TabIndex = 164
        PictureBox8.TabStop = False
        ' 
        ' PictureBox11
        ' 
        PictureBox11.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox11.BackColor = Color.Transparent
        PictureBox11.BackgroundImage = CType(resources.GetObject("PictureBox11.BackgroundImage"), Image)
        PictureBox11.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox11.Cursor = Cursors.Hand
        PictureBox11.Location = New Point(976, 76)
        PictureBox11.Margin = New Padding(3, 2, 3, 2)
        PictureBox11.Name = "PictureBox11"
        PictureBox11.Size = New Size(157, 39)
        PictureBox11.TabIndex = 163
        PictureBox11.TabStop = False
        ' 
        ' PictureBox12
        ' 
        PictureBox12.BackColor = Color.Transparent
        PictureBox12.BackgroundImage = My.Resources.Resources.Picture7
        PictureBox12.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox12.Cursor = Cursors.Hand
        PictureBox12.Location = New Point(12, 11)
        PictureBox12.Margin = New Padding(3, 2, 3, 2)
        PictureBox12.Name = "PictureBox12"
        PictureBox12.Size = New Size(70, 39)
        PictureBox12.TabIndex = 162
        PictureBox12.TabStop = False
        ' 
        ' PictureBox13
        ' 
        PictureBox13.BackColor = Color.Transparent
        PictureBox13.BackgroundImage = My.Resources.Resources.Picture6
        PictureBox13.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox13.Cursor = Cursors.Hand
        PictureBox13.Location = New Point(98, 11)
        PictureBox13.Margin = New Padding(3, 2, 3, 2)
        PictureBox13.Name = "PictureBox13"
        PictureBox13.Size = New Size(55, 39)
        PictureBox13.TabIndex = 161
        PictureBox13.TabStop = False
        ' 
        ' PictureBox14
        ' 
        PictureBox14.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox14.BackColor = Color.Transparent
        PictureBox14.BackgroundImage = My.Resources.Resources.love
        PictureBox14.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox14.Cursor = Cursors.Hand
        PictureBox14.Location = New Point(1746, 11)
        PictureBox14.Margin = New Padding(3, 2, 3, 2)
        PictureBox14.Name = "PictureBox14"
        PictureBox14.Size = New Size(60, 39)
        PictureBox14.TabIndex = 160
        PictureBox14.TabStop = False
        ' 
        ' PictureBox15
        ' 
        PictureBox15.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox15.BackColor = Color.Transparent
        PictureBox15.BackgroundImage = My.Resources.Resources.Picture9
        PictureBox15.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox15.Cursor = Cursors.Hand
        PictureBox15.Location = New Point(1821, 11)
        PictureBox15.Margin = New Padding(3, 2, 3, 2)
        PictureBox15.Name = "PictureBox15"
        PictureBox15.Size = New Size(55, 39)
        PictureBox15.TabIndex = 159
        PictureBox15.TabStop = False
        ' 
        ' High_Budget_Cairo_Hotels_Waldorf_Astoria_Cairo_Heliopolis
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(239), CByte(235), CByte(229))
        ClientSize = New Size(1904, 1041)
        Controls.Add(Label12)
        Controls.Add(PictureBox1)
        Controls.Add(PictureBox7)
        Controls.Add(PictureBox8)
        Controls.Add(PictureBox11)
        Controls.Add(PictureBox12)
        Controls.Add(PictureBox13)
        Controls.Add(PictureBox14)
        Controls.Add(PictureBox15)
        Controls.Add(Label2)
        Controls.Add(PictureBox4)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox9)
        Controls.Add(PictureBox10)
        Controls.Add(Label11)
        Controls.Add(Label10)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(LinkLabel1)
        Controls.Add(PictureBox6)
        Controls.Add(Label5)
        Controls.Add(PictureBox5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label1)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Name = "High_Budget_Cairo_Hotels_Waldorf_Astoria_Cairo_Heliopolis"
        Text = "High_Budget_Cairo_Hotels_Waldorf_Astoria_Cairo_Heliopolis"
        WindowState = FormWindowState.Maximized
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox12, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox13, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox14, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox15, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents Label12 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents PictureBox12 As PictureBox
    Friend WithEvents PictureBox13 As PictureBox
    Friend WithEvents PictureBox14 As PictureBox
    Friend WithEvents PictureBox15 As PictureBox
End Class
