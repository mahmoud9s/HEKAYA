﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class High_Budget_Hurghada_Baron_Palace_Sahl_Hasheesh
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(High_Budget_Hurghada_Baron_Palace_Sahl_Hasheesh))
        PictureBox13 = New PictureBox()
        PictureBox16 = New PictureBox()
        PictureBox11 = New PictureBox()
        PictureBox12 = New PictureBox()
        Label14 = New Label()
        Label13 = New Label()
        Label12 = New Label()
        Label11 = New Label()
        Label10 = New Label()
        Label9 = New Label()
        Label8 = New Label()
        Label7 = New Label()
        Label6 = New Label()
        LinkLabel1 = New LinkLabel()
        PictureBox6 = New PictureBox()
        Label5 = New Label()
        PictureBox5 = New PictureBox()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        PictureBox4 = New PictureBox()
        PictureBox3 = New PictureBox()
        PictureBox2 = New PictureBox()
        PictureBox1 = New PictureBox()
        Label1 = New Label()
        CType(PictureBox13, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox16, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox12, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox13
        ' 
        PictureBox13.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox13.BackColor = Color.Transparent
        PictureBox13.BackgroundImage = My.Resources.Resources.love
        PictureBox13.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox13.Cursor = Cursors.Hand
        PictureBox13.Location = New Point(1777, 1)
        PictureBox13.Name = "PictureBox13"
        PictureBox13.Size = New Size(69, 52)
        PictureBox13.TabIndex = 187
        PictureBox13.TabStop = False
        ' 
        ' PictureBox16
        ' 
        PictureBox16.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox16.BackColor = Color.Transparent
        PictureBox16.BackgroundImage = My.Resources.Resources.Picture9
        PictureBox16.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox16.Cursor = Cursors.Hand
        PictureBox16.Location = New Point(1835, 1)
        PictureBox16.Name = "PictureBox16"
        PictureBox16.Size = New Size(63, 52)
        PictureBox16.TabIndex = 186
        PictureBox16.TabStop = False
        ' 
        ' PictureBox11
        ' 
        PictureBox11.BackColor = Color.Transparent
        PictureBox11.BackgroundImage = My.Resources.Resources.Picture7
        PictureBox11.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox11.Cursor = Cursors.Hand
        PictureBox11.Location = New Point(11, 7)
        PictureBox11.Name = "PictureBox11"
        PictureBox11.Size = New Size(80, 52)
        PictureBox11.TabIndex = 185
        PictureBox11.TabStop = False
        ' 
        ' PictureBox12
        ' 
        PictureBox12.BackColor = Color.Transparent
        PictureBox12.BackgroundImage = My.Resources.Resources.Picture6
        PictureBox12.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox12.Cursor = Cursors.Hand
        PictureBox12.Location = New Point(120, 7)
        PictureBox12.Name = "PictureBox12"
        PictureBox12.Size = New Size(63, 52)
        PictureBox12.TabIndex = 184
        PictureBox12.TabStop = False
        ' 
        ' Label14
        ' 
        Label14.Anchor = AnchorStyles.Left
        Label14.Cursor = Cursors.Hand
        Label14.Font = New Font("Microsoft Sans Serif", 18F)
        Label14.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label14.Location = New Point(9, 1181)
        Label14.Name = "Label14"
        Label14.Size = New Size(589, 49)
        Label14.TabIndex = 183
        Label14.Text = "start from ($250–$500 USD) per night"
        ' 
        ' Label13
        ' 
        Label13.Anchor = AnchorStyles.Left
        Label13.Cursor = Cursors.Hand
        Label13.Font = New Font("Microsoft Sans Serif", 18F)
        Label13.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label13.Location = New Point(303, 932)
        Label13.Name = "Label13"
        Label13.Size = New Size(371, 204)
        Label13.TabIndex = 182
        Label13.Text = "5 swimming pools" & vbCrLf & " free wifi" & vbCrLf & "airport shuttle" & vbCrLf & "family rooms" & vbCrLf & "good breakfast " & vbCrLf
        ' 
        ' Label12
        ' 
        Label12.Anchor = AnchorStyles.Left
        Label12.Cursor = Cursors.Hand
        Label12.Font = New Font("Microsoft Sans Serif", 18F)
        Label12.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label12.Location = New Point(9, 920)
        Label12.Name = "Label12"
        Label12.Size = New Size(301, 215)
        Label12.TabIndex = 181
        Label12.Text = "spa and wellness center tea" & vbCrLf & "coffee maker in all rooms bar " & vbCrLf & "private beach area" & vbCrLf & "beach front" & vbCrLf & vbCrLf & vbCrLf
        ' 
        ' Label11
        ' 
        Label11.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label11.AutoSize = True
        Label11.Font = New Font("Microsoft Sans Serif", 20F)
        Label11.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label11.Location = New Point(77, 1083)
        Label11.Name = "Label11"
        Label11.Size = New Size(356, 39)
        Label11.TabIndex = 180
        Label11.Text = "$132 to $176 per night"
        ' 
        ' Label10
        ' 
        Label10.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label10.AutoSize = True
        Label10.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label10.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label10.Location = New Point(19, 969)
        Label10.Name = "Label10"
        Label10.Size = New Size(251, 46)
        Label10.TabIndex = 179
        Label10.Text = "Price Range"
        ' 
        ' Label9
        ' 
        Label9.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label9.Font = New Font("Microsoft Sans Serif", 20F)
        Label9.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label9.Location = New Point(429, 696)
        Label9.Name = "Label9"
        Label9.Size = New Size(245, 355)
        Label9.TabIndex = 178
        Label9.Text = "Fitness center" & vbCrLf & "Spa" & vbCrLf & "Bar" & vbCrLf & "Good Breakfast" & vbCrLf
        ' 
        ' Label8
        ' 
        Label8.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label8.Font = New Font("Microsoft Sans Serif", 20F)
        Label8.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label8.Location = New Point(77, 696)
        Label8.Name = "Label8"
        Label8.Size = New Size(312, 355)
        Label8.TabIndex = 177
        Label8.Text = "3 swimming pools" & vbCrLf & "Free Wi-fi" & vbCrLf & " Airport shuttle " & vbCrLf & "Family rooms" & vbCrLf & "Private Parking" & vbCrLf
        ' 
        ' Label7
        ' 
        Label7.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label7.AutoSize = True
        Label7.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label7.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label7.Location = New Point(72, 728)
        Label7.Name = "Label7"
        Label7.Size = New Size(428, 46)
        Label7.TabIndex = 176
        Label7.Text = "Most popular facilities"
        ' 
        ' Label6
        ' 
        Label6.Font = New Font("Lucida Sans Unicode", 20.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label6.Location = New Point(72, 341)
        Label6.Name = "Label6"
        Label6.Size = New Size(1102, 443)
        Label6.TabIndex = 175
        Label6.Text = resources.GetString("Label6.Text")
        ' 
        ' LinkLabel1
        ' 
        LinkLabel1.AutoSize = True
        LinkLabel1.Font = New Font("Segoe UI", 20F)
        LinkLabel1.Location = New Point(111, 289)
        LinkLabel1.Name = "LinkLabel1"
        LinkLabel1.Size = New Size(861, 46)
        LinkLabel1.TabIndex = 174
        LinkLabel1.TabStop = True
        LinkLabel1.Text = "Baron Building, Sahl Hasheesh, Sahl Hasheesh, Hurghada"
        ' 
        ' PictureBox6
        ' 
        PictureBox6.BackColor = Color.Transparent
        PictureBox6.BackgroundImage = CType(resources.GetObject("PictureBox6.BackgroundImage"), Image)
        PictureBox6.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox6.Cursor = Cursors.Hand
        PictureBox6.Location = New Point(34, 289)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(50, 49)
        PictureBox6.TabIndex = 173
        PictureBox6.TabStop = False
        ' 
        ' Label5
        ' 
        Label5.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label5.AutoSize = True
        Label5.Font = New Font("Mongolian Baiti", 60F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label5.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label5.Location = New Point(14, 152)
        Label5.Name = "Label5"
        Label5.Size = New Size(1184, 106)
        Label5.TabIndex = 172
        Label5.Text = "Baron Palace Sahl Hasheesh"
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), Image)
        PictureBox5.Location = New Point(1147, 181)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(1029, 1056)
        PictureBox5.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox5.TabIndex = 171
        PictureBox5.TabStop = False
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Cursor = Cursors.Hand
        Label4.Font = New Font("Microsoft Sans Serif", 12F)
        Label4.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label4.Location = New Point(111, 109)
        Label4.Name = "Label4"
        Label4.Size = New Size(84, 25)
        Label4.TabIndex = 170
        Label4.Text = "Hotels >"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Cursor = Cursors.Hand
        Label3.Font = New Font("Microsoft Sans Serif", 12F)
        Label3.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label3.Location = New Point(305, 109)
        Label3.Name = "Label3"
        Label3.Size = New Size(268, 25)
        Label3.TabIndex = 169
        Label3.Text = "Baron Palace Sahl Hasheesh"
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Label2.AutoSize = True
        Label2.BackColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label2.Cursor = Cursors.Hand
        Label2.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Bold)
        Label2.ForeColor = Color.White
        Label2.Location = New Point(1808, 116)
        Label2.Name = "Label2"
        Label2.Size = New Size(106, 25)
        Label2.TabIndex = 168
        Label2.Text = "Book now"
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), Image)
        PictureBox4.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox4.Cursor = Cursors.Hand
        PictureBox4.Location = New Point(1748, 101)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(161, 56)
        PictureBox4.TabIndex = 167
        PictureBox4.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), Image)
        PictureBox3.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox3.Cursor = Cursors.Hand
        PictureBox3.Location = New Point(1788, 108)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(58, 51)
        PictureBox3.TabIndex = 166
        PictureBox3.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), Image)
        PictureBox2.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox2.Cursor = Cursors.Hand
        PictureBox2.Location = New Point(1701, 108)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(53, 51)
        PictureBox2.TabIndex = 165
        PictureBox2.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), Image)
        PictureBox1.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox1.Cursor = Cursors.Hand
        PictureBox1.Location = New Point(1407, 116)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(179, 52)
        PictureBox1.TabIndex = 164
        PictureBox1.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Cursor = Cursors.Hand
        Label1.Font = New Font("Microsoft Sans Serif", 12F)
        Label1.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label1.Location = New Point(34, 109)
        Label1.Name = "Label1"
        Label1.Size = New Size(120, 25)
        Label1.TabIndex = 163
        Label1.Text = "Hurghada > "
        ' 
        ' High_Budget_Hurghada_Baron_Palace_Sahl_Hasheesh
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(239), CByte(235), CByte(229))
        ClientSize = New Size(1924, 1055)
        Controls.Add(PictureBox13)
        Controls.Add(PictureBox16)
        Controls.Add(PictureBox11)
        Controls.Add(PictureBox12)
        Controls.Add(Label14)
        Controls.Add(Label13)
        Controls.Add(Label12)
        Controls.Add(Label11)
        Controls.Add(Label10)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(LinkLabel1)
        Controls.Add(PictureBox6)
        Controls.Add(Label5)
        Controls.Add(PictureBox5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(PictureBox4)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        Controls.Add(Label1)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Name = "High_Budget_Hurghada_Baron_Palace_Sahl_Hasheesh"
        Text = "High_Budget_Hurghada_Baron_Palace_Sahl_Hasheesh"
        WindowState = FormWindowState.Maximized
        CType(PictureBox13, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox16, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox12, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox13 As PictureBox
    Friend WithEvents PictureBox16 As PictureBox
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents PictureBox12 As PictureBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
End Class
