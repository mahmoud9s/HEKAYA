﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Looking_For_Alex
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Looking_For_Alex))
        PictureBox1 = New PictureBox()
        PictureBox8 = New PictureBox()
        PictureBox7 = New PictureBox()
        PictureBox9 = New PictureBox()
        PictureBox10 = New PictureBox()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        PictureBox4 = New PictureBox()
        PictureBox3 = New PictureBox()
        PictureBox2 = New PictureBox()
        Label1 = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), Image)
        PictureBox1.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox1.Cursor = Cursors.Hand
        PictureBox1.Location = New Point(481, 164)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(990, 303)
        PictureBox1.TabIndex = 52
        PictureBox1.TabStop = False
        ' 
        ' PictureBox8
        ' 
        PictureBox8.BackColor = Color.Transparent
        PictureBox8.BackgroundImage = My.Resources.Resources.Picture7
        PictureBox8.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox8.Cursor = Cursors.Hand
        PictureBox8.Location = New Point(12, 11)
        PictureBox8.Margin = New Padding(3, 2, 3, 2)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(70, 39)
        PictureBox8.TabIndex = 51
        PictureBox8.TabStop = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.BackColor = Color.Transparent
        PictureBox7.BackgroundImage = My.Resources.Resources.Picture6
        PictureBox7.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox7.Cursor = Cursors.Hand
        PictureBox7.Location = New Point(98, 11)
        PictureBox7.Margin = New Padding(3, 2, 3, 2)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(55, 39)
        PictureBox7.TabIndex = 50
        PictureBox7.TabStop = False
        ' 
        ' PictureBox9
        ' 
        PictureBox9.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox9.BackColor = Color.Transparent
        PictureBox9.BackgroundImage = My.Resources.Resources.love
        PictureBox9.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox9.Cursor = Cursors.Hand
        PictureBox9.Location = New Point(1760, 11)
        PictureBox9.Margin = New Padding(3, 2, 3, 2)
        PictureBox9.Name = "PictureBox9"
        PictureBox9.Size = New Size(60, 39)
        PictureBox9.TabIndex = 49
        PictureBox9.TabStop = False
        ' 
        ' PictureBox10
        ' 
        PictureBox10.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox10.BackColor = Color.Transparent
        PictureBox10.BackgroundImage = My.Resources.Resources.Picture9
        PictureBox10.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox10.Cursor = Cursors.Hand
        PictureBox10.Location = New Point(1837, 11)
        PictureBox10.Margin = New Padding(3, 2, 3, 2)
        PictureBox10.Name = "PictureBox10"
        PictureBox10.Size = New Size(55, 39)
        PictureBox10.TabIndex = 48
        PictureBox10.TabStop = False
        ' 
        ' Label4
        ' 
        Label4.Anchor = AnchorStyles.Bottom
        Label4.AutoSize = True
        Label4.Cursor = Cursors.Hand
        Label4.Font = New Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold)
        Label4.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label4.Location = New Point(752, 943)
        Label4.Name = "Label4"
        Label4.Size = New Size(157, 31)
        Label4.TabIndex = 47
        Label4.Text = "Landmarks"
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.Bottom
        Label3.AutoSize = True
        Label3.Cursor = Cursors.Hand
        Label3.Font = New Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold)
        Label3.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label3.Location = New Point(1406, 943)
        Label3.Name = "Label3"
        Label3.Size = New Size(173, 31)
        Label3.TabIndex = 46
        Label3.Text = "Restaurants"
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Bottom
        Label2.AutoSize = True
        Label2.Cursor = Cursors.Hand
        Label2.Font = New Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold)
        Label2.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label2.Location = New Point(98, 943)
        Label2.Name = "Label2"
        Label2.Size = New Size(106, 31)
        Label2.TabIndex = 45
        Label2.Text = "Hotels "
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Anchor = AnchorStyles.Bottom
        PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), Image)
        PictureBox4.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox4.Cursor = Cursors.Hand
        PictureBox4.Location = New Point(98, 550)
        PictureBox4.Margin = New Padding(3, 2, 3, 2)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(414, 342)
        PictureBox4.TabIndex = 44
        PictureBox4.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Anchor = AnchorStyles.Bottom
        PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), Image)
        PictureBox3.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox3.Cursor = Cursors.Hand
        PictureBox3.Location = New Point(752, 550)
        PictureBox3.Margin = New Padding(3, 2, 3, 2)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(414, 342)
        PictureBox3.TabIndex = 43
        PictureBox3.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Anchor = AnchorStyles.Bottom
        PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), Image)
        PictureBox2.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox2.Cursor = Cursors.Hand
        PictureBox2.Location = New Point(1406, 550)
        PictureBox2.Margin = New Padding(3, 2, 3, 2)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(414, 342)
        PictureBox2.TabIndex = 42
        PictureBox2.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        Label1.AutoSize = True
        Label1.Font = New Font("Mongolian Baiti", 45F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label1.Location = New Point(636, 76)
        Label1.Name = "Label1"
        Label1.Size = New Size(680, 64)
        Label1.TabIndex = 41
        Label1.Text = "What are you looking for?"
        ' 
        ' Looking_For_Alex
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(239), CByte(235), CByte(229))
        ClientSize = New Size(1904, 1041)
        Controls.Add(PictureBox1)
        Controls.Add(PictureBox8)
        Controls.Add(PictureBox7)
        Controls.Add(PictureBox9)
        Controls.Add(PictureBox10)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(PictureBox4)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox2)
        Controls.Add(Label1)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Name = "Looking_For_Alex"
        Text = "Looking_For_Alex"
        WindowState = FormWindowState.Maximized
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label1 As Label
End Class
