﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Hotels_Alex_moderate_budget
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Hotels_Alex_moderate_budget))
        Label14 = New Label()
        PictureBox12 = New PictureBox()
        Label7 = New Label()
        Label9 = New Label()
        Label12 = New Label()
        Label13 = New Label()
        PictureBox9 = New PictureBox()
        PictureBox11 = New PictureBox()
        Label11 = New Label()
        Label10 = New Label()
        Label8 = New Label()
        Label6 = New Label()
        PictureBox10 = New PictureBox()
        PictureBox3 = New PictureBox()
        PictureBox8 = New PictureBox()
        PictureBox6 = New PictureBox()
        PictureBox7 = New PictureBox()
        PictureBox5 = New PictureBox()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        PictureBox2 = New PictureBox()
        PictureBox1 = New PictureBox()
        PictureBox4 = New PictureBox()
        Label5 = New Label()
        Label1 = New Label()
        Label15 = New Label()
        CType(PictureBox12, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label14
        ' 
        Label14.Anchor = AnchorStyles.Left
        Label14.AutoSize = True
        Label14.BackColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label14.Font = New Font("Microsoft Sans Serif", 18F, FontStyle.Bold)
        Label14.ForeColor = Color.White
        Label14.Location = New Point(410, 211)
        Label14.Name = "Label14"
        Label14.Size = New Size(96, 29)
        Label14.TabIndex = 97
        Label14.Text = "Budget"
        ' 
        ' PictureBox12
        ' 
        PictureBox12.Anchor = AnchorStyles.Left
        PictureBox12.BackgroundImage = My.Resources.Resources.Picture18
        PictureBox12.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox12.Cursor = Cursors.Hand
        PictureBox12.Location = New Point(340, 164)
        PictureBox12.Margin = New Padding(3, 2, 3, 2)
        PictureBox12.Name = "PictureBox12"
        PictureBox12.Size = New Size(240, 103)
        PictureBox12.TabIndex = 94
        PictureBox12.TabStop = False
        ' 
        ' Label7
        ' 
        Label7.Anchor = AnchorStyles.Right
        Label7.Cursor = Cursors.Hand
        Label7.Font = New Font("Microsoft Sans Serif", 18F)
        Label7.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label7.Location = New Point(1467, 707)
        Label7.Name = "Label7"
        Label7.Size = New Size(402, 177)
        Label7.TabIndex = 107
        Label7.Text = "Novotel Cairo El Borg offers rooms with Nile or city views, a pool, gym, and rooftop restaurant. It’s located near Cairo Tower and 12 miles from the Pyramids."
        ' 
        ' Label9
        ' 
        Label9.Anchor = AnchorStyles.Left
        Label9.Cursor = Cursors.Hand
        Label9.Font = New Font("Microsoft Sans Serif", 18F)
        Label9.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label9.Location = New Point(479, 707)
        Label9.Name = "Label9"
        Label9.Size = New Size(444, 232)
        Label9.TabIndex = 106
        Label9.Text = "Amoun Hotel Alexandria is a 3-star hotel in Mansheya, offering panoramic views, comfortable rooms with balconies, wooden floors, and minibars, just 3 km from the ancient Lighthouse of Alexandria."
        ' 
        ' Label12
        ' 
        Label12.Anchor = AnchorStyles.Right
        Label12.AutoSize = True
        Label12.Cursor = Cursors.Hand
        Label12.Font = New Font("Microsoft Sans Serif", 25F, FontStyle.Bold)
        Label12.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label12.Location = New Point(2050, 849)
        Label12.Name = "Label12"
        Label12.Size = New Size(312, 39)
        Label12.TabIndex = 105
        Label12.Text = "Grand Plaza Hotel"
        ' 
        ' Label13
        ' 
        Label13.Anchor = AnchorStyles.Left
        Label13.AutoSize = True
        Label13.Cursor = Cursors.Hand
        Label13.Font = New Font("Microsoft Sans Serif", 25F, FontStyle.Bold)
        Label13.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label13.Location = New Point(479, 650)
        Label13.Name = "Label13"
        Label13.Size = New Size(225, 39)
        Label13.TabIndex = 104
        Label13.Text = "Amoun Hotel"
        ' 
        ' PictureBox9
        ' 
        PictureBox9.Anchor = AnchorStyles.Right
        PictureBox9.BackgroundImage = CType(resources.GetObject("PictureBox9.BackgroundImage"), Image)
        PictureBox9.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox9.BorderStyle = BorderStyle.FixedSingle
        PictureBox9.Cursor = Cursors.Hand
        PictureBox9.Location = New Point(1042, 643)
        PictureBox9.Margin = New Padding(3, 2, 3, 2)
        PictureBox9.Name = "PictureBox9"
        PictureBox9.Size = New Size(400, 273)
        PictureBox9.TabIndex = 103
        PictureBox9.TabStop = False
        ' 
        ' PictureBox11
        ' 
        PictureBox11.Anchor = AnchorStyles.Left
        PictureBox11.BackgroundImage = CType(resources.GetObject("PictureBox11.BackgroundImage"), Image)
        PictureBox11.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox11.BorderStyle = BorderStyle.FixedSingle
        PictureBox11.Cursor = Cursors.Hand
        PictureBox11.Location = New Point(98, 643)
        PictureBox11.Margin = New Padding(3, 2, 3, 2)
        PictureBox11.Name = "PictureBox11"
        PictureBox11.Size = New Size(359, 273)
        PictureBox11.TabIndex = 102
        PictureBox11.TabStop = False
        ' 
        ' Label11
        ' 
        Label11.Anchor = AnchorStyles.Right
        Label11.Cursor = Cursors.Hand
        Label11.Font = New Font("Microsoft Sans Serif", 18F)
        Label11.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label11.Location = New Point(1467, 409)
        Label11.Name = "Label11"
        Label11.Size = New Size(402, 193)
        Label11.TabIndex = 101
        Label11.Text = "Situated near the Montazah Royal Gardens and close to Mamoura Beach, the hotel is in a quieter area but still accessible to key attractions like the Catacombs of Kom El Shoqafa (15 km away)."
        ' 
        ' Label10
        ' 
        Label10.Anchor = AnchorStyles.Left
        Label10.Cursor = Cursors.Hand
        Label10.Font = New Font("Microsoft Sans Serif", 18F)
        Label10.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label10.Location = New Point(479, 409)
        Label10.Name = "Label10"
        Label10.Size = New Size(385, 193)
        Label10.TabIndex = 100
        Label10.Text = "Blue Alex Hotel is located centrally in Alexandria, offering various apartments suitable for families and individuals. It features sea views and proximity to key attractions and amenities."
        ' 
        ' Label8
        ' 
        Label8.Anchor = AnchorStyles.Right
        Label8.AutoSize = True
        Label8.Cursor = Cursors.Hand
        Label8.Font = New Font("Microsoft Sans Serif", 25F, FontStyle.Bold)
        Label8.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label8.Location = New Point(2041, 545)
        Label8.Name = "Label8"
        Label8.Size = New Size(351, 39)
        Label8.TabIndex = 99
        Label8.Text = "Eastern Al Montazah"
        ' 
        ' Label6
        ' 
        Label6.Anchor = AnchorStyles.Left
        Label6.AutoSize = True
        Label6.Cursor = Cursors.Hand
        Label6.Font = New Font("Microsoft Sans Serif", 25F, FontStyle.Bold)
        Label6.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label6.Location = New Point(479, 346)
        Label6.Name = "Label6"
        Label6.Size = New Size(171, 39)
        Label6.TabIndex = 98
        Label6.Text = "Blue Alex"
        ' 
        ' PictureBox10
        ' 
        PictureBox10.Anchor = AnchorStyles.Right
        PictureBox10.BackgroundImage = CType(resources.GetObject("PictureBox10.BackgroundImage"), Image)
        PictureBox10.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox10.BorderStyle = BorderStyle.FixedSingle
        PictureBox10.Cursor = Cursors.Hand
        PictureBox10.Location = New Point(1042, 329)
        PictureBox10.Margin = New Padding(3, 2, 3, 2)
        PictureBox10.Name = "PictureBox10"
        PictureBox10.Size = New Size(400, 273)
        PictureBox10.TabIndex = 96
        PictureBox10.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Anchor = AnchorStyles.Left
        PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), Image)
        PictureBox3.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox3.BorderStyle = BorderStyle.FixedSingle
        PictureBox3.Cursor = Cursors.Hand
        PictureBox3.Location = New Point(98, 329)
        PictureBox3.Margin = New Padding(3, 2, 3, 2)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(359, 273)
        PictureBox3.TabIndex = 95
        PictureBox3.TabStop = False
        ' 
        ' PictureBox8
        ' 
        PictureBox8.BackColor = Color.Transparent
        PictureBox8.BackgroundImage = My.Resources.Resources.Picture7
        PictureBox8.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox8.Cursor = Cursors.Hand
        PictureBox8.Location = New Point(12, 11)
        PictureBox8.Margin = New Padding(3, 2, 3, 2)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(70, 39)
        PictureBox8.TabIndex = 93
        PictureBox8.TabStop = False
        ' 
        ' PictureBox6
        ' 
        PictureBox6.BackColor = Color.Transparent
        PictureBox6.BackgroundImage = My.Resources.Resources.Picture6
        PictureBox6.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox6.Cursor = Cursors.Hand
        PictureBox6.Location = New Point(98, 11)
        PictureBox6.Margin = New Padding(3, 2, 3, 2)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(55, 39)
        PictureBox6.TabIndex = 92
        PictureBox6.TabStop = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox7.BackColor = Color.Transparent
        PictureBox7.BackgroundImage = My.Resources.Resources.love
        PictureBox7.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox7.Cursor = Cursors.Hand
        PictureBox7.Location = New Point(1765, 11)
        PictureBox7.Margin = New Padding(3, 2, 3, 2)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(60, 39)
        PictureBox7.TabIndex = 91
        PictureBox7.TabStop = False
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox5.BackColor = Color.Transparent
        PictureBox5.BackgroundImage = My.Resources.Resources.Picture9
        PictureBox5.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox5.Cursor = Cursors.Hand
        PictureBox5.Location = New Point(1839, 11)
        PictureBox5.Margin = New Padding(3, 2, 3, 2)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(55, 39)
        PictureBox5.TabIndex = 90
        PictureBox5.TabStop = False
        ' 
        ' Label4
        ' 
        Label4.Anchor = AnchorStyles.Right
        Label4.AutoSize = True
        Label4.BackColor = Color.White
        Label4.Cursor = Cursors.Hand
        Label4.Font = New Font("Microsoft Sans Serif", 18F)
        Label4.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label4.Location = New Point(1287, 211)
        Label4.Name = "Label4"
        Label4.Size = New Size(144, 29)
        Label4.TabIndex = 88
        Label4.Text = "High budget"
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.None
        Label3.AutoSize = True
        Label3.BackColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label3.Cursor = Cursors.Hand
        Label3.Font = New Font("Microsoft Sans Serif", 18F, FontStyle.Bold)
        Label3.ForeColor = Color.White
        Label3.Location = New Point(953, 211)
        Label3.Name = "Label3"
        Label3.Size = New Size(212, 29)
        Label3.TabIndex = 87
        Label3.Text = "Moderate budget"
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Left
        Label2.AutoSize = True
        Label2.BackColor = Color.White
        Label2.Cursor = Cursors.Hand
        Label2.Font = New Font("Microsoft Sans Serif", 18F)
        Label2.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label2.Location = New Point(681, 211)
        Label2.Name = "Label2"
        Label2.Size = New Size(139, 29)
        Label2.TabIndex = 86
        Label2.Text = "Low budget"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Anchor = AnchorStyles.None
        PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), Image)
        PictureBox2.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox2.Cursor = Cursors.Hand
        PictureBox2.Location = New Point(938, 164)
        PictureBox2.Margin = New Padding(3, 2, 3, 2)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(240, 103)
        PictureBox2.TabIndex = 85
        PictureBox2.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Anchor = AnchorStyles.Right
        PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), Image)
        PictureBox1.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox1.Cursor = Cursors.Hand
        PictureBox1.Location = New Point(1237, 164)
        PictureBox1.Margin = New Padding(3, 2, 3, 2)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(240, 103)
        PictureBox1.TabIndex = 84
        PictureBox1.TabStop = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Anchor = AnchorStyles.Left
        PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), Image)
        PictureBox4.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox4.Cursor = Cursors.Hand
        PictureBox4.Location = New Point(639, 164)
        PictureBox4.Margin = New Padding(3, 2, 3, 2)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(240, 103)
        PictureBox4.TabIndex = 83
        PictureBox4.TabStop = False
        ' 
        ' Label5
        ' 
        Label5.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        Label5.AutoSize = True
        Label5.BackColor = Color.FromArgb(CByte(239), CByte(235), CByte(229))
        Label5.Font = New Font("Mongolian Baiti", 60F)
        Label5.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label5.Location = New Point(938, 77)
        Label5.Name = "Label5"
        Label5.Size = New Size(246, 85)
        Label5.TabIndex = 108
        Label5.Text = "Hotels"
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Left
        Label1.AutoSize = True
        Label1.Cursor = Cursors.Hand
        Label1.Font = New Font("Microsoft Sans Serif", 25F, FontStyle.Bold)
        Label1.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label1.Location = New Point(1467, 346)
        Label1.Name = "Label1"
        Label1.Size = New Size(351, 39)
        Label1.TabIndex = 109
        Label1.Text = "Eastern Al Montazah"
        ' 
        ' Label15
        ' 
        Label15.Anchor = AnchorStyles.Left
        Label15.AutoSize = True
        Label15.Cursor = Cursors.Hand
        Label15.Font = New Font("Microsoft Sans Serif", 25F, FontStyle.Bold)
        Label15.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label15.Location = New Point(1467, 643)
        Label15.Name = "Label15"
        Label15.Size = New Size(217, 39)
        Label15.TabIndex = 110
        Label15.Text = "Grand Plaza"
        ' 
        ' Hotels_Alex_moderate_budget
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(239), CByte(235), CByte(229))
        ClientSize = New Size(1904, 1041)
        Controls.Add(Label15)
        Controls.Add(Label1)
        Controls.Add(Label5)
        Controls.Add(Label14)
        Controls.Add(PictureBox12)
        Controls.Add(Label7)
        Controls.Add(Label9)
        Controls.Add(Label12)
        Controls.Add(Label13)
        Controls.Add(PictureBox9)
        Controls.Add(PictureBox11)
        Controls.Add(Label11)
        Controls.Add(Label10)
        Controls.Add(Label8)
        Controls.Add(Label6)
        Controls.Add(PictureBox10)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox8)
        Controls.Add(PictureBox6)
        Controls.Add(PictureBox7)
        Controls.Add(PictureBox5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        Controls.Add(PictureBox4)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Name = "Hotels_Alex_moderate_budget"
        Text = "Hotels_Alex_moderate_budget"
        WindowState = FormWindowState.Maximized
        CType(PictureBox12, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label14 As Label
    Friend WithEvents PictureBox12 As PictureBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label15 As Label
End Class
