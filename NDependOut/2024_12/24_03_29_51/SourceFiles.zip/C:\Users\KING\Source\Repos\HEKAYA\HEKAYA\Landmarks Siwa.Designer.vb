﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Landmarks_Siwa
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Landmarks_Siwa))
        Label11 = New Label()
        Label10 = New Label()
        Label9 = New Label()
        Label8 = New Label()
        Label7 = New Label()
        Label6 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        Label5 = New Label()
        PictureBox8 = New PictureBox()
        PictureBox7 = New PictureBox()
        PictureBox9 = New PictureBox()
        PictureBox10 = New PictureBox()
        PictureBox6 = New PictureBox()
        PictureBox4 = New PictureBox()
        PictureBox3 = New PictureBox()
        PictureBox1 = New PictureBox()
        Label1 = New Label()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label11
        ' 
        Label11.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        Label11.Cursor = Cursors.Hand
        Label11.Font = New Font("Microsoft Sans Serif", 18F)
        Label11.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label11.Location = New Point(648, 830)
        Label11.Name = "Label11"
        Label11.Size = New Size(415, 193)
        Label11.TabIndex = 118
        Label11.Text = "Gabal el-Mawta, or ""Mountain of the Dead,"" is a necropolis in the Siwa Oasis, Egypt, with tombs from the 26th Dynasty and the Greco-Roman period, offering insights into ancient burial practices."
        ' 
        ' Label10
        ' 
        Label10.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        Label10.Cursor = Cursors.Hand
        Label10.Font = New Font("Microsoft Sans Serif", 18F)
        Label10.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label10.Location = New Point(1651, 830)
        Label10.Name = "Label10"
        Label10.Size = New Size(415, 193)
        Label10.TabIndex = 117
        Label10.Text = "The Temple of Amun in the Siwa Oasis, Egypt, was dedicated to the god Amun and is historically significant, especially during Alexander the Great's time."
        ' 
        ' Label9
        ' 
        Label9.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        Label9.Cursor = Cursors.Hand
        Label9.Font = New Font("Microsoft Sans Serif", 18F)
        Label9.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label9.Location = New Point(648, 830)
        Label9.Name = "Label9"
        Label9.Size = New Size(415, 0)
        Label9.TabIndex = 116
        Label9.Text = resources.GetString("Label9.Text")
        ' 
        ' Label8
        ' 
        Label8.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        Label8.Cursor = Cursors.Hand
        Label8.Font = New Font("Microsoft Sans Serif", 18F)
        Label8.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label8.Location = New Point(1651, 264)
        Label8.Name = "Label8"
        Label8.Size = New Size(415, 247)
        Label8.TabIndex = 115
        Label8.Text = "Geological Nature Dakrour Mountain is composed of limestone and sedimentary rocks, believed to have been part of an ancient seabed."
        ' 
        ' Label7
        ' 
        Label7.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        Label7.Cursor = Cursors.Hand
        Label7.Font = New Font("Microsoft Sans Serif", 18F)
        Label7.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label7.Location = New Point(1651, 830)
        Label7.Name = "Label7"
        Label7.Size = New Size(415, 0)
        Label7.TabIndex = 114
        Label7.Text = "Stanley Bridge, inaugurated in 2001 in Alexandria, is a 400-meter Italian-inspired structure on the Corniche. It eases traffic, offers Mediterranean views, and is popular with tourists and locals."
        ' 
        ' Label6
        ' 
        Label6.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        Label6.Cursor = Cursors.Hand
        Label6.Font = New Font("Microsoft Sans Serif", 18F)
        Label6.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label6.Location = New Point(648, 264)
        Label6.Name = "Label6"
        Label6.Size = New Size(415, 261)
        Label6.TabIndex = 113
        Label6.Text = "Cleopatra’s Bath is a famous spring in the Siwa Oasis, Egypt, popular for its clear, mineral-rich waters. Despite its name, there’s no evidence Cleopatra visited it."
        ' 
        ' Label4
        ' 
        Label4.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        Label4.AutoSize = True
        Label4.Cursor = Cursors.Hand
        Label4.Font = New Font("Microsoft Sans Serif", 21F, FontStyle.Bold)
        Label4.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label4.Location = New Point(648, 768)
        Label4.Name = "Label4"
        Label4.Size = New Size(277, 39)
        Label4.TabIndex = 112
        Label4.Text = "Gabal El-Mawta"
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        Label3.AutoSize = True
        Label3.Cursor = Cursors.Hand
        Label3.Font = New Font("Microsoft Sans Serif", 21F, FontStyle.Bold)
        Label3.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label3.Location = New Point(1651, 768)
        Label3.Name = "Label3"
        Label3.Size = New Size(285, 39)
        Label3.TabIndex = 111
        Label3.Text = "Temple of Amun"
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        Label2.AutoSize = True
        Label2.Cursor = Cursors.Hand
        Label2.Font = New Font("Microsoft Sans Serif", 21F, FontStyle.Bold)
        Label2.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label2.Location = New Point(1651, 205)
        Label2.Name = "Label2"
        Label2.Size = New Size(436, 39)
        Label2.TabIndex = 110
        Label2.Text = "Dakrour Mountain in Siwa"
        ' 
        ' Label5
        ' 
        Label5.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        Label5.AutoSize = True
        Label5.Cursor = Cursors.Hand
        Label5.Font = New Font("Microsoft Sans Serif", 21F, FontStyle.Bold)
        Label5.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label5.Location = New Point(648, 205)
        Label5.Name = "Label5"
        Label5.Size = New Size(320, 39)
        Label5.TabIndex = 109
        Label5.Text = "Cleopatra’s Spring"
        ' 
        ' PictureBox8
        ' 
        PictureBox8.BackColor = Color.Transparent
        PictureBox8.BackgroundImage = My.Resources.Resources.Picture7
        PictureBox8.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox8.Cursor = Cursors.Hand
        PictureBox8.Location = New Point(4, 9)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(80, 52)
        PictureBox8.TabIndex = 108
        PictureBox8.TabStop = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.BackColor = Color.Transparent
        PictureBox7.BackgroundImage = My.Resources.Resources.Picture6
        PictureBox7.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox7.Cursor = Cursors.Hand
        PictureBox7.Location = New Point(102, 9)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(63, 52)
        PictureBox7.TabIndex = 107
        PictureBox7.TabStop = False
        ' 
        ' PictureBox9
        ' 
        PictureBox9.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox9.BackColor = Color.Transparent
        PictureBox9.BackgroundImage = My.Resources.Resources.love
        PictureBox9.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox9.Cursor = Cursors.Hand
        PictureBox9.Location = New Point(1734, 9)
        PictureBox9.Name = "PictureBox9"
        PictureBox9.Size = New Size(69, 52)
        PictureBox9.TabIndex = 106
        PictureBox9.TabStop = False
        ' 
        ' PictureBox10
        ' 
        PictureBox10.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox10.BackColor = Color.Transparent
        PictureBox10.BackgroundImage = My.Resources.Resources.Picture9
        PictureBox10.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox10.Cursor = Cursors.Hand
        PictureBox10.Location = New Point(1820, 9)
        PictureBox10.Name = "PictureBox10"
        PictureBox10.Size = New Size(63, 52)
        PictureBox10.TabIndex = 105
        PictureBox10.TabStop = False
        ' 
        ' PictureBox6
        ' 
        PictureBox6.Anchor = AnchorStyles.Right
        PictureBox6.BackgroundImage = CType(resources.GetObject("PictureBox6.BackgroundImage"), Image)
        PictureBox6.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox6.BorderStyle = BorderStyle.FixedSingle
        PictureBox6.Cursor = Cursors.Hand
        PictureBox6.Location = New Point(1094, 768)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(549, 501)
        PictureBox6.TabIndex = 104
        PictureBox6.TabStop = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Anchor = AnchorStyles.Left
        PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), Image)
        PictureBox4.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox4.BorderStyle = BorderStyle.FixedSingle
        PictureBox4.Cursor = Cursors.Hand
        PictureBox4.Location = New Point(92, 768)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(549, 501)
        PictureBox4.TabIndex = 103
        PictureBox4.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Anchor = AnchorStyles.Right
        PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), Image)
        PictureBox3.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox3.BorderStyle = BorderStyle.FixedSingle
        PictureBox3.Cursor = Cursors.Hand
        PictureBox3.Location = New Point(1094, 205)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(549, 501)
        PictureBox3.TabIndex = 102
        PictureBox3.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Anchor = AnchorStyles.Left
        PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), Image)
        PictureBox1.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox1.BorderStyle = BorderStyle.FixedSingle
        PictureBox1.Cursor = Cursors.Hand
        PictureBox1.Location = New Point(92, 205)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(549, 501)
        PictureBox1.TabIndex = 101
        PictureBox1.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        Label1.AutoSize = True
        Label1.Font = New Font("Mongolian Baiti", 45F)
        Label1.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label1.Location = New Point(887, 49)
        Label1.Name = "Label1"
        Label1.Size = New Size(372, 80)
        Label1.TabIndex = 100
        Label1.Text = "Landmarks"
        ' 
        ' Landmarks_Siwa
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(239), CByte(235), CByte(229))
        ClientSize = New Size(1902, 1033)
        Controls.Add(Label11)
        Controls.Add(Label10)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label5)
        Controls.Add(PictureBox8)
        Controls.Add(PictureBox7)
        Controls.Add(PictureBox9)
        Controls.Add(PictureBox10)
        Controls.Add(PictureBox6)
        Controls.Add(PictureBox4)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox1)
        Controls.Add(Label1)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Name = "Landmarks_Siwa"
        Text = "Landmarks_Siwa"
        WindowState = FormWindowState.Maximized
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
End Class
