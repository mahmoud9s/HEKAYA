﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Restaurants_Siwa_Ali_Aliwa_Grill_Restaurant
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Restaurants_Siwa_Ali_Aliwa_Grill_Restaurant))
        Label18 = New Label()
        Label1 = New Label()
        Label9 = New Label()
        Label11 = New Label()
        Label12 = New Label()
        Label13 = New Label()
        PictureBox4 = New PictureBox()
        PictureBox2 = New PictureBox()
        PictureBox3 = New PictureBox()
        Label14 = New Label()
        Label10 = New Label()
        Label8 = New Label()
        Label7 = New Label()
        Label6 = New Label()
        LinkLabel1 = New LinkLabel()
        PictureBox6 = New PictureBox()
        Label5 = New Label()
        PictureBox1 = New PictureBox()
        PictureBox8 = New PictureBox()
        PictureBox7 = New PictureBox()
        PictureBox9 = New PictureBox()
        PictureBox10 = New PictureBox()
        PictureBox5 = New PictureBox()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label18
        ' 
        Label18.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label18.Font = New Font("Microsoft Sans Serif", 20F)
        Label18.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label18.Location = New Point(10, 553)
        Label18.Name = "Label18"
        Label18.Size = New Size(1079, 184)
        Label18.TabIndex = 424
        Label18.Text = "SThe restaurant specializes in grilled dishes cooked in a traditional stone oven. Signature meals include:"
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label1.AutoSize = True
        Label1.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label1.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label1.Location = New Point(12, 493)
        Label1.Name = "Label1"
        Label1.Size = New Size(389, 46)
        Label1.TabIndex = 423
        Label1.Text = "Cuisine Specialties:"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Cursor = Cursors.Hand
        Label9.Font = New Font("Microsoft Sans Serif", 12F)
        Label9.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label9.Location = New Point(134, 72)
        Label9.Name = "Label9"
        Label9.Size = New Size(133, 25)
        Label9.TabIndex = 422
        Label9.Text = "Restaurants >"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Cursor = Cursors.Hand
        Label11.Font = New Font("Microsoft Sans Serif", 12F)
        Label11.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label11.Location = New Point(262, 72)
        Label11.Name = "Label11"
        Label11.Size = New Size(223, 25)
        Label11.TabIndex = 421
        Label11.Text = "Ali Aliwa Grill Restaurant"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Cursor = Cursors.Hand
        Label12.Font = New Font("Microsoft Sans Serif", 12F)
        Label12.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label12.Location = New Point(7, 72)
        Label12.Name = "Label12"
        Label12.Size = New Size(77, 25)
        Label12.TabIndex = 420
        Label12.Text = "Siwa > "
        ' 
        ' Label13
        ' 
        Label13.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Label13.AutoSize = True
        Label13.BackColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label13.Cursor = Cursors.Hand
        Label13.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Bold)
        Label13.ForeColor = Color.White
        Label13.Location = New Point(1777, 112)
        Label13.Name = "Label13"
        Label13.Size = New Size(106, 25)
        Label13.TabIndex = 419
        Label13.Text = "Book now"
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), Image)
        PictureBox4.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox4.Cursor = Cursors.Hand
        PictureBox4.Location = New Point(1738, 96)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(142, 65)
        PictureBox4.TabIndex = 418
        PictureBox4.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), Image)
        PictureBox2.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox2.Cursor = Cursors.Hand
        PictureBox2.Location = New Point(1834, 106)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(53, 43)
        PictureBox2.TabIndex = 417
        PictureBox2.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), Image)
        PictureBox3.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox3.Cursor = Cursors.Hand
        PictureBox3.Location = New Point(1669, 103)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(51, 51)
        PictureBox3.TabIndex = 416
        PictureBox3.TabStop = False
        ' 
        ' Label14
        ' 
        Label14.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label14.AutoSize = True
        Label14.Font = New Font("Microsoft Sans Serif", 20F, FontStyle.Bold)
        Label14.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label14.Location = New Point(43, 895)
        Label14.Name = "Label14"
        Label14.Size = New Size(0, 39)
        Label14.TabIndex = 415
        ' 
        ' Label10
        ' 
        Label10.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label10.AutoSize = True
        Label10.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label10.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label10.Location = New Point(539, 830)
        Label10.Name = "Label10"
        Label10.Size = New Size(0, 46)
        Label10.TabIndex = 414
        ' 
        ' Label8
        ' 
        Label8.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label8.Font = New Font("Microsoft Sans Serif", 20F)
        Label8.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label8.Location = New Point(23, 428)
        Label8.Name = "Label8"
        Label8.Size = New Size(392, 56)
        Label8.TabIndex = 413
        Label8.Text = "EGP 510 to 1,300."
        ' 
        ' Label7
        ' 
        Label7.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label7.AutoSize = True
        Label7.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label7.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label7.Location = New Point(11, 378)
        Label7.Name = "Label7"
        Label7.Size = New Size(263, 46)
        Label7.TabIndex = 412
        Label7.Text = "Price Range:"
        ' 
        ' Label6
        ' 
        Label6.Font = New Font("Lucida Sans Unicode", 22.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label6.Location = New Point(6, 234)
        Label6.Name = "Label6"
        Label6.Size = New Size(1259, 194)
        Label6.TabIndex = 411
        Label6.Text = resources.GetString("Label6.Text")
        ' 
        ' LinkLabel1
        ' 
        LinkLabel1.AutoSize = True
        LinkLabel1.Font = New Font("Segoe UI", 20F)
        LinkLabel1.LinkColor = SystemColors.HotTrack
        LinkLabel1.Location = New Point(67, 184)
        LinkLabel1.Name = "LinkLabel1"
        LinkLabel1.Size = New Size(853, 46)
        LinkLabel1.TabIndex = 410
        LinkLabel1.TabStop = True
        LinkLabel1.Text = "Batokhy Street, Siwa Oasis, Matrouh Governorate, Egypt"
        ' 
        ' PictureBox6
        ' 
        PictureBox6.BackColor = Color.Transparent
        PictureBox6.BackgroundImage = CType(resources.GetObject("PictureBox6.BackgroundImage"), Image)
        PictureBox6.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox6.Cursor = Cursors.Hand
        PictureBox6.Location = New Point(11, 182)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(50, 48)
        PictureBox6.TabIndex = 409
        PictureBox6.TabStop = False
        ' 
        ' Label5
        ' 
        Label5.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label5.AutoSize = True
        Label5.Font = New Font("Mongolian Baiti", 46F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.ForeColor = Color.FromArgb(CByte(98), CByte(62), CByte(42))
        Label5.Location = New Point(6, 98)
        Label5.Name = "Label5"
        Label5.Size = New Size(870, 82)
        Label5.TabIndex = 408
        Label5.Text = "Ali Aliwa Grill Restaurant"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), Image)
        PictureBox1.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox1.Cursor = Cursors.Hand
        PictureBox1.Location = New Point(1118, 111)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(179, 51)
        PictureBox1.TabIndex = 406
        PictureBox1.TabStop = False
        ' 
        ' PictureBox8
        ' 
        PictureBox8.BackColor = Color.Transparent
        PictureBox8.BackgroundImage = My.Resources.Resources.Picture7
        PictureBox8.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox8.Cursor = Cursors.Hand
        PictureBox8.Location = New Point(6, 12)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(80, 51)
        PictureBox8.TabIndex = 405
        PictureBox8.TabStop = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.BackColor = Color.Transparent
        PictureBox7.BackgroundImage = My.Resources.Resources.Picture6
        PictureBox7.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox7.Cursor = Cursors.Hand
        PictureBox7.Location = New Point(105, 12)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(63, 51)
        PictureBox7.TabIndex = 404
        PictureBox7.TabStop = False
        ' 
        ' PictureBox9
        ' 
        PictureBox9.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox9.BackColor = Color.Transparent
        PictureBox9.BackgroundImage = My.Resources.Resources.love
        PictureBox9.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox9.Cursor = Cursors.Hand
        PictureBox9.Location = New Point(1759, 12)
        PictureBox9.Name = "PictureBox9"
        PictureBox9.Size = New Size(69, 51)
        PictureBox9.TabIndex = 403
        PictureBox9.TabStop = False
        ' 
        ' PictureBox10
        ' 
        PictureBox10.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox10.BackColor = Color.Transparent
        PictureBox10.BackgroundImage = My.Resources.Resources.Picture9
        PictureBox10.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox10.Cursor = Cursors.Hand
        PictureBox10.Location = New Point(1829, 12)
        PictureBox10.Name = "PictureBox10"
        PictureBox10.Size = New Size(63, 51)
        PictureBox10.TabIndex = 402
        PictureBox10.TabStop = False
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), Image)
        PictureBox5.Location = New Point(865, 167)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(1015, 933)
        PictureBox5.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox5.TabIndex = 407
        PictureBox5.TabStop = False
        ' 
        ' Restaurants_Siwa_Ali_Aliwa_Grill_Restaurant
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(239), CByte(235), CByte(229))
        ClientSize = New Size(1902, 1033)
        Controls.Add(Label18)
        Controls.Add(Label1)
        Controls.Add(Label9)
        Controls.Add(Label11)
        Controls.Add(Label12)
        Controls.Add(Label13)
        Controls.Add(PictureBox4)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox3)
        Controls.Add(Label14)
        Controls.Add(Label10)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(LinkLabel1)
        Controls.Add(PictureBox6)
        Controls.Add(Label5)
        Controls.Add(PictureBox1)
        Controls.Add(PictureBox8)
        Controls.Add(PictureBox7)
        Controls.Add(PictureBox9)
        Controls.Add(PictureBox10)
        Controls.Add(PictureBox5)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Name = "Restaurants_Siwa_Ali_Aliwa_Grill_Restaurant"
        Text = "Restaurants_Siwa_Ali_Aliwa_Grill_Restaurant"
        WindowState = FormWindowState.Maximized
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label18 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
End Class
